jQuery(document).ready(function(){ 
  jQuery("form#reg-form").validate({
         ignore: ":hidden", 
    
    rules: {
        txt_fname: {
            required: true,
            minlength: 2
        },
        txt_lname: {
            required: true,
            minlength: 2
        },
        txt_email: {
            required: true,
            email: true
        },
        txt_linkedin: {
            required: true,
            url: true
        },
        txt_website: {
            url: true
        }     
    
    },
     messages: {        
        txt_fname: {
          required: "Please enter your First Name",
          minlength: "Your First Name must be at least 2 characters long"
        },
        txt_lname: {
          required: "Please enter your Last Name",
          minlength: "Your Last Name must be at least 2 characters long"
        },
        txt_email: {
          required: "Please enter your Email Address",
          email: "Please enter a valid email address"
        },
        txt_linkedin: {
          required: "Please enter your LinkedIn Address",
          url: "Please enter Valid LinkedIn Address"
        },
        txt_website: {
          url: "Please enter Valid Website Address"
        }
    },
    submitHandler: function(form) {
          jQuery.ajax({
              url: BASE_URL + '/yes-mls-form-success/', 
              type: "POST",             
              data: jQuery('#reg-form').serialize(),
              success: function(data) {             

                jQuery("#message").show();
                   setTimeout(function() { 
                        jQuery("#message").hide(); 
                    }, 2000);
                jQuery("#reg-form")[0].reset();
                }

          });
          return false;
    }   

  });
});