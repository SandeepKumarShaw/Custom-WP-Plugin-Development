<?php
/*
  Plugin Name: Yes Mls Form
  Plugin URI: https://www.example.com/
  Description: This plugin integrates yes mls enquery form
  Version: 1.0
  Author: WP Team
  Author URI: https://www.example.com/
*/


if (!defined('ABSPATH')){//Exit if accessed directly
    exit;
}
define( 'YMF_VERSION', '1.0' );
define( 'YMF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'YMF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

include_once('inc/YMF_shortcode.php');
include_once('inc/YMF_success_page.php');
include_once('inc/YMF_succes.php');
//include_once('inc/YMF_mail.php');




register_activation_hook(__FILE__, 'ymfsuc_install' );
register_deactivation_hook(__FILE__, 'ymfsuc_deactivation' );

function ymf_success_foo() {

    return YMF_Form_Submit_success(); 
}
add_shortcode('ymf_success', 'ymf_success_foo');

//===================style & script enque===================//
add_action( 'wp_enqueue_scripts', 'ymf_enqueue_scripts' );

function ymf_enqueue_scripts() {

wp_enqueue_script('ymf-jqueryValidateJs',YMF_PLUGIN_URL.'js/jquery.validate.js', array('jquery'),'', true );

wp_enqueue_script('ymf_jquery',YMF_PLUGIN_URL.'js/ymf_common.js', array(),'', true );

wp_enqueue_style('ymf-custom-css', YMF_PLUGIN_URL.'css/ymfstyle.css');	
		
}

function site_url_link(){?>
<script type="text/javascript">
	var BASE_URL = '<?php echo site_url(); ?>'; 
</script>

<?php }
add_action('wp_head','site_url_link');



/**
 * This function will connect wp_mail to your authenticated
 * SMTP server. This improves reliability of wp_mail, and 
 * avoids many potential problems.
 * 
 * Values are constants set in wp-config.php
 */
add_action( 'phpmailer_init', 'send_smtp_email' );
function send_smtp_email( $phpmailer ) {
  $phpmailer->isSMTP();
  $phpmailer->Host       = 'ssl://smtp.gmail.com';
  $phpmailer->SMTPAuth   = TRUE;
  $phpmailer->Port       = 465;
  $phpmailer->Username   = 'registration@yesmls.com';
  $phpmailer->Password   = 'Just4U%%';
  $phpmailer->SMTPSecure = TRUE;
  $phpmailer->From       = 'registration@yesmls.com';
  $phpmailer->FromName   = 'YESMLS';
}





