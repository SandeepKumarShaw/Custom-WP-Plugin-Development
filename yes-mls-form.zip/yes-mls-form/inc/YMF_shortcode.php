<?php
ob_start();
function yes_mls_form(){
?>
<div class="container1">
    <div class="main1">
    <div id="message" style="display:none">Application Recived</div>
        <form name="reg-form2" method="post" id="reg-form">
            <h2>Get Your Personal Access Code</h2>
            <div class="fname66">
                <label>First Name :</label>
                <input type="text" name="txt_fname" id="txt_fname">
            </div>
            <div class="lname34">
                <label>Last Name :</label>
                <input type="text" name="txt_lname" id="txt_lname">    
            </div>
            <div class="email667">
                <label>Email :</label>
                <input type="text" name="txt_email" id="txt_email">    
            </div>
            <div class="company23">
                <label>Company :</label>
                <input type="text" name="txt_company" id="txt_company">    
            </div>
            <div class="websites3">
                <label>Website :</label>
                <input type="text" name="txt_website" id="txt_website">    
            </div>
            <div class="linkedin234">
                <label>LinkedIn :</label>
                <input type="text" name="txt_linkedin" id="txt_linkedin">    
            </div>
                <input type="submit" id="register" value="Submit" />

        </form>
    </div>
</div>
<?php }

add_shortcode('wp_yes_mls_form', 'yes_mls_form');
return ob_get_clean();
