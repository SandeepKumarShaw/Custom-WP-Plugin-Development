<?php 
ob_start();

function YMF_Form_Submit_success(){
if( $_POST ){	

$con=mysqli_connect("localhost","yesmls12_app","#~}&LpW}~Jy$","yesmls12_app");

//$con=mysqli_connect("localhost","root","","cias");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// escape variables for security
$fname    = mysqli_real_escape_string($con, $_POST['txt_fname']);
$lname    = mysqli_real_escape_string($con, $_POST['txt_lname']);
$email    = mysqli_real_escape_string($con, $_POST['txt_email']);
$company  = mysqli_real_escape_string($con, $_POST['txt_company']);
$website  = mysqli_real_escape_string($con, $_POST['txt_website']);
$linkedin = mysqli_real_escape_string($con, $_POST['txt_linkedin']);

include_once('YMF_mail.php');

$to = $email;
$subject = "Thank you for applying";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$send_mail = wp_mail($to,$subject,$msg,$headers);
if($send_mail){
	$sql="INSERT INTO immo_registration (fname, lname, email, company, website, linkedIn)
		VALUES ('$fname', '$lname', '$email', '$company', '$website', '$linkedin')";
		if (!mysqli_query($con,$sql)) {
		  die('Error: ' . mysqli_error($con));
		}
		$sbc = "1 record added";

		return $sbc;
}

mysqli_close($con);
	
}
}
