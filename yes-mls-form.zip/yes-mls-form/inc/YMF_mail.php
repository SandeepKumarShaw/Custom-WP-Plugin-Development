<?php 
$msg = '<br><br><br><br><br><br><br><br><table width="582" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="578"><table width="580" height="400" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01">
      
      <tr>
        
        <td width="355" align="center" valign="top"><table width="340" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>
              <font size="2" face="Arial, Helvetica, Geneva, SunSans-Regular, sans-serif">&nbsp;
                  <!-- <h1 style="color: #505050; display: block; font-family: Arial; font-size: 28px; font-weight: bold; line-height: 100%; margin-top: 0; margin-right: 0; margin-bottom: 10px; margin-left: 0; text-align: left;" class="h1"> Signup Code </h1> -->
                  <p style="margin-bottom: 20px;">
                   In order to ensure our members that YESMLS is used by transaction based Real-Estate professionals only, we will review your request based upon the information you enclosed and send you a reply within 24 hours.
                  </p>                          
                  <p style="margin-bottom: 20px;"></p><br><br>
                   Kind regards,<br>
                   YESMLS
                    <!-- <?php echo date("Y");?> &copy; yesmls.com -->
              </font>
            </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        
      </tr>
    </table>
    </td>
  </tr>
</table>';

?>











