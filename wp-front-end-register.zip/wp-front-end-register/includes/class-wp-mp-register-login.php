<?php
/**
 * The file that defines the core plugin class
 *
 */

class Wp_Mp_Register_Login
{

    public function __construct()
    {
        define('WP_MP_PLUGIN_PATH', plugin_dir_path(__FILE__)); 

       $this->plugin_name = 'wp-mp-register-login';
       $this->version = 2.02;
        //$this->load_dependencies();

        $this->define_public_hooks();
    }


    private function define_public_hooks()
    {

        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        add_action('wpmp_register_form', array($this, 'wpmp_display_register_form'));
        add_shortcode('wpmp_register_form', array($this, 'wpmp_display_register_form'));

        add_action('wp_footer', array($this, 'wpmp_load_custo_modal'));



        add_action('wp_ajax_nopriv_wpmp_user_registration', array($this, 'wpmp_user_registration'));
        add_action('wp_ajax_wpmp_user_registration', array($this, 'wpmp_user_registration'));




    }  
        public function enqueue_styles()
    {

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'public/css/wp-mp-register-login-public.css', array(), $this->version, 'all');
        wp_enqueue_style($this->plugin_name . '-bootstrap', plugin_dir_url(__FILE__) . 'public/css/bootstrap.min.css', array(), $this->version, 'all');
        wp_enqueue_style($this->plugin_name . '-formValidation', plugin_dir_url(__FILE__) . 'public/css/formValidation.min.css', array(), $this->version, 'all');
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

          wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'public/js/wp-mp-register-login-public.js', array('jquery'), $this->version, false);
        wp_enqueue_script($this->plugin_name . '-bootstrap', plugin_dir_url(__FILE__) . 'public/js/bootstrap.min.js', array('jquery'), $this->version, false);
        wp_enqueue_script($this->plugin_name . '-formValidation.min', plugin_dir_url(__FILE__) . 'public/js/validator/formValidation.min.js', array('jquery'), $this->version, false);
        wp_enqueue_script($this->plugin_name . '-bootstrap-validator', plugin_dir_url(__FILE__) . 'public/js/validator/bootstrap-validator.min.js', array('jquery'), $this->version, false);
        // localizing gloabl js objects
        wp_localize_script($this->plugin_name, 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    }
        public function wpmp_check_user_verified_email_or_not($credentials)
    {
        // getting user details
        $user = get_user_by('login', $credentials['user_login']);

        if (!$user->ID) {
            $response['error'] = __('The username you have entered does not exist.', $this->plugin_name);
        } else {
            $stored_token = get_user_meta($user->ID, 'wpmp_email_verification_token', true);
            if (!$stored_token) {
                return true;
            }
        }
        wp_send_json($response);
    }

    /**
     * Render the registration form and verify token if present
     *
     * @since   1.0.0
     */
    public function wpmp_display_register_form()
    {
        // verifing token if present
        ob_start();
        //$token_verification = $this->wpmp_verify_token();
        include_once WP_MP_PLUGIN_PATH. 'public/wpmp-register-form.php';
        return ob_get_clean();  
    }
    public function wpmp_load_custo_modal(){
        include_once WP_MP_PLUGIN_PATH. 'public/wpmp-custom-modal.php';
    }
    /**
     * User registration
     * @return json
     * @since   1.0.0
     */
    public function wpmp_user_registration()
    {

       // $wpmp_email_settings = get_option('wpmp_email_settings');
        $response = array();

       // checking post data
        if (isset($_POST) && $_POST) {

            $nonce = $_POST['wpmp_register_nonce'];
            // For security : verifying wordpress nonce
            if (!wp_verify_nonce($nonce, 'wpmp_register_action')) {
                _e('Failed security check !', $this->plugin_name);
                exit;
            }
            // preparing user array and added required filters
            $userdata = array(
                'user_login' => apply_filters('pre_user_login', trim($_POST['wpmp_email'])),
                'user_pass' => apply_filters('pre_user_pass', trim($_POST['wpmp_password'])),
                'user_email' => apply_filters('pre_user_email', trim($_POST['wpmp_email'])),
                'first_name' => apply_filters('pre_user_first_name', trim($_POST['wpmp_fname'])),
                'last_name' => apply_filters('pre_user_last_name', trim($_POST['wpmp_lname'])),
                'role' => get_option('default_role'),
                'user_registered' => date('Y-m-d H:i:s')
            );

            // creating new user
            $user_id = wp_insert_user($userdata);

            // checking for errors while user registration
            if (is_wp_error($user_id)) {
                $response['error'] = $user_id->get_error_message();
            } else {

                //adding current url in user data
                $userdata['current_url'] = $_POST['wpmp_current_url'];

                // Adding hook so that anyone can add action on user registration
                do_action('user_register', $user_id);

                wp_set_auth_cookie( $user_id );
                wp_set_current_user( $user_id );

                $response['reg_status'] = true;
                $this->wpmp_user_registration_mail($userdata);
                $response['success'] = __('You are successfully registered.', $this->plugin_name);
              
            }
            // sending back the response in right header
            wp_send_json($response);
        }
    }
    public function wpmp_user_registration_mail($userdata)
    {

   
        $to['admin'] = get_option('admin_email');

        $subject['admin'] = get_option('blogname') . ' | New user registered';

        // using content type html for emails
        $headers = array('Content-Type: text/html; charset=UTF-8');

        //Make body of admin message
        $userprofile.= '<br><strong>' . __('Username : ') . '</strong>' . $userdata['user_email'];
        $userprofile.= '<br><strong>' . __('Email : ') . '</strong>' . $userdata['user_email'];

        $message['admin'] = sprintf(__('A new user has registered on %s with following details:'), get_option('blogname'));

      

        $footer['admin'] = '<br><br>' . __('Thanks.');

        $body['admin'] = $message['admin'] . $userprofile . $footer['admin'];


        //sending email notification to admin
        wp_mail($to['admin'], $subject['admin'], $body['admin'], $headers);

    }   
}
