<?php
/**
 * Provide a public-facing view for the plugin
 
 */

?>

<div id="wpmpRegisterSection" class="container-fluid">
    <div class="row">
        <div class="col-xs-8 col-md-10"> 
            <?php

            if ( in_array( $_SERVER['REMOTE_ADDR'], array( '127.0.0.1', '::1' ) )) {
                $key = "6Lf6VLAUAAAAAPqPJUEFT87XM6JWU4D3HOzyB1AA";
            }else{
                 $key = "6LdDULAUAAAAAM1j5f30p5WgBsT6NMtd5JoByeGx";
            }    
            
            // check if the user already login
            if (!is_user_logged_in()) :

                ?>

                <form name="wpmpRegisterForm" id="wpmpRegisterForm" method="post" onsubmit="return submitUserForm();">
                    <div id="wpmp-reg-loader-info" class="wpmp-loader" style="display:none;">
                        <img src="<?php echo plugins_url('images/ajax-loader.gif', dirname(__FILE__)); ?>"/>
                        <span><?php _e('Please wait ...', $this->plugin_name); ?></span>
                    </div>
                    <div id="wpmp-register-alert" class="alert alert-danger" role="alert" style="display:none;"></div>
                    <div id="wpmp-mail-alert" class="alert alert-danger" role="alert" style="display:none;"></div>
                   
                    <div class="form-group">
                        <label for="firstname"><?php _e('Your name', $this->plugin_name); ?></label>
                        <sup class="wpmp-required-asterisk">*</sup>
                        <input type="text" class="form-control" name="wpmp_fname" id="wpmp_fname" placeholder="Your name">
                    </div>
                   
                    <div class="form-group">
                        <label for="email"><?php _e('E-mail address', $this->plugin_name); ?></label>
                        <sup class="wpmp-required-asterisk">*</sup>
                        <input type="text" class="form-control" name="wpmp_email" id="wpmp_email" placeholder="E-mail address">
                    </div>
                    <div class="form-group">
                        <label for="password"><?php _e('Password', $this->plugin_name); ?></label>
                        <sup class="wpmp-required-asterisk">*</sup>
                        <input type="password" class="form-control" name="wpmp_password" id="wpmp_password" placeholder="Password" >
                    </div>
                    <div class="form-group">
                        <label for="confrim password"><?php _e('Re-type password', $this->plugin_name); ?></label>
                        <sup class="wpmp-required-asterisk">*</sup>
                        <input type="password" class="form-control" name="wpmp_password2" id="wpmp_password2" placeholder="Re-type password" >
                    </div>


                    <div class="form-group">
                        <input type="checkbox" class="" name="wpmp_checkbox" id="wpmp_checkbox" value="1">
                        I agree to the <a href="<?php echo site_url(); ?>/terms-of-use">terms of use.</a>        
                    </div>
                    <div class="form-group">
                        
                        <div class="g-recaptcha" data-sitekey="<?php echo $key; ?>" data-callback="verifyCaptcha"></div>
                        <div id="g-recaptcha-error"></div>

                        
                    </div>


                    <input type="hidden" name="wpmp_current_url" id="wpmp_current_url" value="<?php echo get_permalink(); ?>" />
                    <input type="hidden" name="redirection_url" id="redirection_url" value="<?php echo site_url().'/welcome-dashboard/'; ?>" />

                    <?php
                    // this prevent automated script for unwanted spam
                    if (function_exists('wp_nonce_field'))
                        wp_nonce_field('wpmp_register_action', 'wpmp_register_nonce');

                    ?>
                    <button type="submit" class="btn btn-primary account-create-submit jrButton jrLarge jrGreen">
                        <?php
                        $submit_button_text = 'Register new account';
                        _e($submit_button_text, $this->plugin_name);

                        ?></button>
                </form>
                <?php
            else:
                $current_user = wp_get_current_user();
                $logout_redirect = (empty($wpmp_form_settings['wpmp_logout_redirect']) || $wpmp_form_settings['wpmp_logout_redirect'] == '-1') ? '' : $wpmp_form_settings['wpmp_logout_redirect'];

                echo 'Logged in as <strong>' . ucfirst($current_user->user_login) . '</strong>. <a href="' . wp_logout_url(get_permalink($logout_redirect)) . '">Log out ? </a>';
            endif;

            ?>
        </div>
    </div>
</div>


<script>
function submitUserForm() {
    var response = grecaptcha.getResponse();
    if(response.length == 0) {
        document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:#a94442;">Please verify you are not a robot.</span>';
        return false;
    }
    return true;
}
 
function verifyCaptcha() {
    document.getElementById('g-recaptcha-error').innerHTML = '';
}
</script>
