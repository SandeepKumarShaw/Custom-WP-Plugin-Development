<?php if(is_front_page() && !is_user_logged_in()){ ?>
    <script src="<?php echo site_url() . '/wp-content/plugins/wp-front-end-register/includes/public/js/jquery.cookie.js'; ?>" ></script>
<script src='https://www.google.com/recaptcha/api.js'></script>

<script type="text/javascript">

jQuery(document).ready(function($){
   if ($ .cookie("popup_1_2") == null) {
        $('#registermodal').modal({
             backdrop: 'static',
             keyboard: false
         });
        $(".hidelogopenreg").click( function()
         {
            $('#registermodal').modal('hide')
            $('#modal-success').modal({
                 backdrop: 'static',
                 keyboard: false
             });
         }
        );
    $ .cookie("popup_1_2", "2");
    }
});
</script>
<?php } ?>
<div id="registermodal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close hidelogopenreg" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h3 class="modal-title" id="modalLabel">Register for a new account</h3>
            </div>
            <div class="modal-body">
                <?php echo do_shortcode("[wpmp_register_form]"); ?>
 
            </div>
            <div class="modal-footer">
              <div class="options text-right">
                <p class="pt-1">Already have an account? <a href="<?php echo site_url().'/sign-up/'?>" class="blue-text">Log In</a></p>
              </div>            
            </div>
        </div>
    </div>
</div>
<div id="modal-success" class="modal modal-message modal-success fade" style="display: none;" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                </div>
                <div class="modal-title"></div>
                <div class="modal-body">Register Now to get better use of the site - It's FREE!</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-dismiss="modal">close</button>
                </div>
            </div> <!-- / .modal-content -->
        </div> <!-- / .modal-dialog -->
    </div>
    <!--End Success Modal Templates-->