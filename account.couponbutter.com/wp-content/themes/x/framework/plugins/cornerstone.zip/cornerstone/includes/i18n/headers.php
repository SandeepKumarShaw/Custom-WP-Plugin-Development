<?php

return array(
  'unassigned' => __( 'Unassigned', 'cornerstone' ),
  'module-delete-confirm' => __( 'Are you sure you want to delete this module? This can not be undone.', 'cornerstone' ),
  'entry-delete-confirm' => __( 'Are you sure you want to delete this header? This can not be undone.', 'cornerstone' ),
);
