<div class="tco-form-setting">
  <div class="tco-form-setting-info">
    <label for="<?php echo $for; ?>">
      <strong><?php echo $title; ?></strong>
      <span><?php echo $description; ?></span>
    </label>
  </div>
  <div class="tco-form-setting-control"><?php echo $control; ?></div>
</div>