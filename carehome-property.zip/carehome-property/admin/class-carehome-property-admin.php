<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin 
 */
class Carehomesdirect_Property_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	private $type               = 'property';
    private $slug               = 'properties';
    private $name               = 'Properties';
    private $singular_name      = 'Property';

    public $meta_fields = array( 'title', 'description', 'siteurl', 'category', 'post_tags' );


	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/carehome-property-admin.css', array(), $this->version, 'all' );

		 wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wp-gallery-metabox-admin.css', array(), $this->version, 'all');
        wp_enqueue_style('custm_wp_gallery_metabox', plugin_dir_url(__FILE__) . 'css/custm_wp_gallery_metabox.css', '', time());
        wp_enqueue_style('gallery-metabox_cstm_css', plugin_dir_url(__FILE__) . 'css/gallery-metabox.css', '', time());

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/carehome-property-admin.js', array( 'jquery' ), $this->version, false );

		 wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wp-gallery-metabox-admin.js', array('jquery'), $this->version, false);
        wp_enqueue_script('gallery_metabox_cstm_js', plugin_dir_url(__FILE__) . 'js/gallery-metabox.js', '', time());

	}
	public function propert_post_type_register() {
        $labels = array(
            'name'                  => $this->name,
            'singular_name'         => $this->singular_name,
            'add_new'               => 'Add New',
            'add_new_item'          => 'Add New '   . $this->singular_name,
            'edit_item'             => 'Edit '      . $this->singular_name,
            'new_item'              => 'New '       . $this->singular_name,
            'all_items'             => 'All '       . $this->name,
            'view_item'             => 'View '      . $this->name,
            'search_items'          => 'Search '    . $this->name,
            'not_found'             => 'No '        . strtolower($this->name) . ' found',
            'not_found_in_trash'    => 'No '        . strtolower($this->name) . ' found in Trash',
            'parent_item_colon'     => '',
            'menu_name'             => $this->name
        );
        $args = array(
            'labels'                => $labels,
            'public'                => true,
            'publicly_queryable'    => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'query_var'             => true,
            'rewrite'               => array( 'slug' => $this->slug ),
            'capability_type'       => 'post',
            'has_archive'           => true,
            'hierarchical'          => true,
            'menu_position'         => 8,
            'taxonomies'            =>  array('category'),
            'menu_icon'             => 'dashicons-admin-home',
            'supports'              => array( 'title', 'editor', 'author', 'thumbnail'),
            'yarpp_support'         => true
        );
        register_post_type( $this->type, $args );
    }
	public function site_edit_columns($columns) {
       $columns = array(
		'cb' 		=> '<input type="checkbox" />',
		'title' 		=> 'Property Title',
		'url'	 	=> 'URL',
		'category'	=> 'Category',
		'post_tags' => 'Tags',
		'siteurl' 	=> 'Screenshot',
       );
       return $columns;
    }
    public function site_custom_columns($column) {
	   global $post;
       switch ($column) {
           case "title" : the_title();
               break;
           case "url" : $m = $this->mshot(150); echo '<a href="'.$m[0].'" target="_blank">'.$m[0].'</a>';
			break;
           case "category" : the_category();
			break;
           case "post_tags" : the_tags('',', ');
               break;
           case "siteurl" : $m = $this->mshot(150); echo $m[1];
			break;
       }
    }
	public function location_get_meta( $value ) {
		global $post;

		$field = get_post_meta( $post->ID, $value, true );
		if ( ! empty( $field ) ) {
			return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
		} else {
			return false;
		}
	}
	public function contact_information_get_meta( $value ) {
		global $post;

		$field = get_post_meta( $post->ID, $value, true );
		if ( ! empty( $field ) ) {
			return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
		} else {
			return false;
		}
	}
	public function location_add_meta_box() {
		add_meta_box(
			'location-location',
			__( 'Location', 'location' ),
			array(&$this, "location_html"),
			'property',
			'normal',
			'default'
		);
		add_meta_box(
			'contact_information-contact-information',
			__( 'Contact Information', 'contact_information' ),
			array(&$this, "contact_information_html"),
			'property',
			'normal',
			'default'
		);
		 add_meta_box(
                    'gallery-metabox', 'Gallery', array($this, 'gallery_meta_callback'), 'property', 'normal', 'high'
            );
	}
	public function location_html( $post) {
		wp_nonce_field( '_location_nonce', 'location_nonce' ); ?>

		<p>
			<label for="location_address"><?php _e( 'Address', 'location' ); ?></label><br>
			<textarea name="location_address" id="location_address" cols="50" rows="5" class="widefat"><?php echo $this->location_get_meta( 'location_address' ); ?></textarea>
		
		</p>	
		<p>
			<label for="location_state"><?php _e( 'State', 'location' ); ?></label><br>
			<input type="text" name="location_state" class="widefat" id="location_state" value="<?php echo $this->location_get_meta( 'location_state' ); ?>">
		</p>	<p>
			<label for="location_city"><?php _e( 'City', 'location' ); ?></label><br>
			<input type="text" name="location_city" id="location_city" class="widefat" value="<?php echo $this->location_get_meta( 'location_city' ); ?>">
		</p>	<p>
			<label for="location_zip_code"><?php _e( 'Zip Code', 'location' ); ?></label><br>
			<input type="text" name="location_zip_code" id="location_zip_code" class="widefat" value="<?php echo $this->location_get_meta( 'location_zip_code' ); ?>">
		</p><?php
	}
	public function contact_information_html( $post) {
		wp_nonce_field( '_contact_information_nonce', 'contact_information_nonce' ); ?>

		<p>
			<label for="contact_information_phone_number"><?php _e( 'Phone Number', 'contact_information' ); ?></label><br>
			<input type="text" name="contact_information_phone_number" id="contact_information_phone_number" value="<?php echo $this->contact_information_get_meta( 'contact_information_phone_number' ); ?>">
		</p>	<p>
			<label for="contact_information_website_url"><?php _e( 'Website Url', 'contact_information' ); ?></label><br>
			<input type="text" name="contact_information_website_url" id="contact_information_website_url" value="<?php echo $this->contact_information_get_meta( 'contact_information_website_url' ); ?>">
		</p>	<p>
			<label for="contact_information_licience"><?php _e( 'Licience', 'contact_information' ); ?></label><br>
			<input type="text" name="contact_information_licience" id="contact_information_licience" value="<?php echo $this->contact_information_get_meta( 'contact_information_licience' ); ?>">
		</p><?php
	}
	public function gallery_meta_callback($post) {
        wp_nonce_field(basename(__FILE__), 'gallery_meta_nonce');
        $ids = get_post_meta($post->ID, 'vdw_gallery_id', true);
        ?>
        <table class="form-table">
            <tr>
                <td>
                    <a class="gallery-add button" href="#" data-uploader-title="Add image(s) to gallery" data-uploader-button-text="Add image(s)">Add image(s)</a>
                    <ul id="gallery-metabox-list">
                        <?php if ($ids) : foreach ($ids as $key => $value) : $image = wp_get_attachment_image_src($value); ?>
                                <li>
                                    <input type="hidden" name="vdw_gallery_id[<?php echo $key; ?>]" value="<?php echo $value; ?>">
                                    <img class="image-preview" src="<?php echo $image[0]; ?>">
                                    <a class="change-image button button-small" href="#" data-uploader-title="Change image" data-uploader-button-text="Change image">Change image</a><br>
                                    <small><a class="remove-image" href="#">Remove image</a></small>
                                </li>
                                <?php
                            endforeach;
                        endif;
                        ?>
                    </ul>
                </td>
            </tr>
        </table>
        <?php
    }
	public function location_save( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( ! isset( $_POST['location_nonce'] ) || ! wp_verify_nonce( $_POST['location_nonce'], '_location_nonce' ) ) return;
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;

		if ( isset( $_POST['location_address'] ) )
			update_post_meta( $post_id, 'location_address', esc_attr( $_POST['location_address'] ) );
		if ( isset( $_POST['location_state'] ) )
			update_post_meta( $post_id, 'location_state', esc_attr( $_POST['location_state'] ) );
		if ( isset( $_POST['location_city'] ) )
			update_post_meta( $post_id, 'location_city', esc_attr( $_POST['location_city'] ) );
		if ( isset( $_POST['location_zip_code'] ) )
			update_post_meta( $post_id, 'location_zip_code', esc_attr( $_POST['location_zip_code'] ) );
	}
	public function contact_information_save( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( ! isset( $_POST['contact_information_nonce'] ) || ! wp_verify_nonce( $_POST['contact_information_nonce'], '_contact_information_nonce' ) ) return;
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;

		if ( isset( $_POST['contact_information_phone_number'] ) )
			update_post_meta( $post_id, 'contact_information_phone_number', esc_attr( $_POST['contact_information_phone_number'] ) );
		if ( isset( $_POST['contact_information_website_url'] ) )
			update_post_meta( $post_id, 'contact_information_website_url', esc_attr( $_POST['contact_information_website_url'] ) );
		if ( isset( $_POST['contact_information_licience'] ) )
			update_post_meta( $post_id, 'contact_information_licience', esc_attr( $_POST['contact_information_licience'] ) );
	}
	public function gallery_meta_save($post_id) {
        if (!isset($_POST['gallery_meta_nonce']) || !wp_verify_nonce($_POST['gallery_meta_nonce'], basename(__FILE__)))
            return;

        if (!current_user_can('edit_post', $post_id))
            return;

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;

        if (isset($_POST['vdw_gallery_id'])) {
            update_post_meta($post_id, 'vdw_gallery_id', $_POST['vdw_gallery_id']);
        } else {
            delete_post_meta($post_id, 'vdw_gallery_id');
        }
    }

}
