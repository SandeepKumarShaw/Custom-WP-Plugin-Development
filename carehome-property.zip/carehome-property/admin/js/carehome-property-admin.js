jQuery(document).ready( function($) {
  // Disable search and ordering by default
$.extend( $.fn.dataTable.defaults, {
    searching: false,
    ordering:  false,
    lengthChange: false
} );

   $('#claim_listing_property').DataTable();
      $('#customers').DataTable();

   $('#customersPlan').DataTable();

/*==================================  Custom Tab Functionality ================================*/		
	 	$('ul.tabs li').click(function(){
			var tab_id = $(this).attr('data-tab');

			$('ul.tabs li').removeClass('current');
			$('.tab-content').removeClass('current');

			$(this).addClass('current');
			$("#"+tab_id).addClass('current');
		});

/*====================================== Plan Add With Validation ============================*/
$.validator.addMethod('selectcheck', function (value) {
        return (value != '0');
    }, "Please select Plan Interval");

$('#addmoreplan').validate({

	rules: {
	    addmorename: {         
	        required: true, 
	        minlength: 5,      
	    },
	    addmoreqty: {          
	        selectcheck: true 
	    },
	    addmoreprice: {           
	        required: true,
	        digits: true
	    }
	},
    messages: {              
        addmorename: {
              required:"Please Enter Plan Name.",
              minlength:"Plan Name at least 5 character long"
              },
        addmoreprice: {
              required: "Please Enter Plan Price",
              minlength: "Please Enter Valid Price"
              }
    },

    submitHandler: function(form) {
        $.ajax({
          url: ajax_params.ajax_url,
          type: 'post',
          data: $(form).serialize(),
          success:function(data) {
          	$("#addmoreplan")[0].reset();

           // console.log(data);
                $('.plan_success').html(data);
			      setTimeout(function(){
			        $('.plan_success').fadeOut();
			    },3000);
          },
          error: function(errorThrown){
              console.log(errorThrown);
          }
      });
    }
});	

/*=========================================== Product CSV IMport ===================================*/
    $("#frmCSVImport").on("submit", function (e) {
      var spinner = $('#loader');
      e.preventDefault();
      $("#response").attr("class", "");
        $("#response").html("");
        var fileType = ".csv";
        var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + fileType + ")$");
        if (!regex.test($("#form_handler_file").val().toLowerCase())) {
              $("#response").addClass("error");
              $("#response").addClass("display-block");
            $("#response").html("Invalid File. Upload : <b>" + fileType + "</b> Files.");
            return false;
        }else{
          spinner.show();
          var form_handler_file = $('input[name=form_handler_file]')[0].files[0];
        var action = $("#form_handler_action").val();
        var post_data = new FormData();    
          post_data.append( 'form_handler_file', form_handler_file );
          post_data.append( 'action', action );

          $.ajax({
            url: ajax_params.ajax_url,
            type:"POST",  
             data:new FormData(this),  
             contentType:false,          // The content type used when sending data to the server.  
             cache:false,                // To unable request pages to be cached  
             processData:false,          // To send DOMDocument or non processed data file it is set to false  
             success: function(data){  
              console.log(data);
              spinner.hide();
              $("#response1").addClass("success");
              $("#response1").addClass("display-block");
              $("#response1").html("Import File Succesfully!.");
            },
            error: function(errorThrown){
                console.log(errorThrown);
            }
        });
        }
        return true;
    });  	



});
/*============================================ DELETE PLAN ===========================================*/
  function delPlan(id, pid){
      
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this Plan!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajax_params.ajax_url,
                        type : "POST",
                        data : {'action' : 'property_stripe_plan_del', 'id' :id, 'pid' :pid},
                        success: function(data){
                            swal("Poof! Your Plan has been deleted!", {
                            icon: "success",
                            });
                           // loadProduct();
                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Plan is safe!");
                }
            });
  }

 /*=========================================== Approved Claim Property =============================*/
   function upClaimProperty(id, pid){
      
            swal({
                title: "Are you sure?",
                text: "Once you, approved this property, this property will assign to user!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajax_params.ajax_url,
                        type : "POST",
                        data : {'action' : 'property_claim_approved', 'id' :id, 'pid' :pid},
                        success: function(data){
                            swal("Poof! User Property has been approved!", {
                            icon: "success",
                            });
                           window.location.reload();

                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("Your Property is safe!");
                }
            });
  } 

     function downClaimProperty(id, pid){
      
            swal({
                title: "Are you sure?",
                text: "Once you, Unapproved this property, this property will assign back to admin!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    jQuery.ajax({
                        url: ajax_params.ajax_url,
                        type : "POST",
                        data : {'action' : 'property_claim_unapproved', 'id' :id, 'pid' :pid},
                        success: function(data){
                            swal("Poof! User Property has been decline!", {
                            icon: "success",
                            });
                           window.location.reload();

                        },
                        error : function(data){
                            swal({
                                title: 'Opps...',
                                text : data.responseJSON.message,
                                type : 'error',
                                timer : '3000'
                            })
                        }
                    })
                } else {
                swal("User Property is safe!");
                }
            });
  } 

/*============================================ END =================================================*/

