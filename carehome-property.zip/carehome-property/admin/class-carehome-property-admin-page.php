<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehomesdirect_Property
 * @subpackage Carehomesdirect_Property/admin/partials
 */

class Carehomesdirect_Property_Admin_Page {

	
	public function property_importer_page_output() {?>
		<h1>Property Importer</h1>
		<?php
		if(isset($_GET['import_from']) && ! empty($_GET['import_from'])) {
			?>
			<form method="post">
				<?php wp_nonce_field('property-import', 'property-import'); ?>
				<table class="">
					<tbody>
						<tr>
							<td>Confirm import?</td>
							<td><input type="hidden" name="import_from" value="<?php echo $_GET['import_from']; ?>"></td>
						</tr>
					</tbody>
				</table>
				<p class="submit">
					<input type="submit" name="submit" id="submit" class="button button-primary" value="Import">
				</p>
			</form>
			<?php 
		} else {
			?>
			<form method="post" enctype="multipart/form-data">
				<?php wp_nonce_field('upload-spreadsheet', 'upload-spreadsheet'); ?>
				<table class="">
					<tbody>
						<tr>
							<td>Upload file (.csv)</td>
							<td><input type="file" name="spreadsheet" accept=".csv"></td>
						</tr>
					</tbody>
				</table>
				<p class="submit">
					<input type="submit" name="submit" id="submit" class="button button-primary" value="Upload">
				</p>
			</form>
			<?php
		}
	}
	public function property_importer_page() {		
	    add_menu_page('Property Importer', 'Property Importer', 'manage_options', 'property-importer', array(&$this, "property_importer_page_output") );
	}
	function form_handler() {
		if(isset($_POST['upload-spreadsheet']) && wp_verify_nonce($_POST['upload-spreadsheet'], 'upload-spreadsheet')) {
			//print_r($_FILES);
			$wordpress_upload_dir = wp_upload_dir();
			$i = 1;
			//print_r($wordpress_upload_dir['path']);die;
			$profilepicture = $_FILES['spreadsheet'];
			$new_file_path = $wordpress_upload_dir['path'] . '/' . $profilepicture['name'];
			$new_file_mime = mime_content_type( $profilepicture['tmp_name'] );
			 
			if( empty( $profilepicture ) )
				die( 'File is not selected.' );
			 
			if( $profilepicture['error'] )
				die( $profilepicture['error'] );
			 
			if( $profilepicture['size'] > wp_max_upload_size() )
				die( 'It is too large than expected.' );
			 
			if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
				die( 'WordPress doesn\'t allow this type of uploads.' );
			 
			while( file_exists( $new_file_path ) ) {
				$i++;
				$new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $profilepicture['name'];
			}
			 
			if( move_uploaded_file( $profilepicture['tmp_name'], $new_file_path ) ) {
				$upload_id = wp_insert_attachment( array(
					'guid'           => $new_file_path, 
					'post_mime_type' => $new_file_mime,
					'post_title'     => preg_replace( '/\.[^.]+$/', '', $profilepicture['name'] ),
					'post_content'   => '',
					'post_status'    => 'inherit'
				), $new_file_path );
			 
				
			 
				wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

				$fullsize_path = get_attached_file( $upload_id );
				
				$args = [
					'page' => 'property-importer',
					'import_from' => $upload_id,

				];	 
				// Show the uploaded file in browser
				$actionurl = add_query_arg($args, admin_url('admin.php'));
				//wp_redirect(wp_nonce_url($actionurl, 'confirm-import', 'confirm-import'));
				wp_redirect($actionurl);
			 	die;
			}
		}

		if(isset($_POST['property-import']) && wp_verify_nonce($_POST['property-import'], 'property-import') && isset($_POST['import_from'])) {
			$upload_id = $_POST['import_from'];

			$fullsize_path = get_attached_file($upload_id);

			if(! empty($fullsize_path)) {
				$ext = pathinfo($fullsize_path, PATHINFO_EXTENSION);
				if($ext != 'csv') {
					'Not a .csv file.';
					return;
				}
				$i = 0;
				$file = fopen($fullsize_path, 'r');
				fgetcsv($file);
				while(! feof($file)) {
					$row = fgetcsv($file); ++ $i;
					//print_r($row);die;
					$wordpress_upload_dir = wp_upload_dir();
					//print_r($wordpress_upload_dir['url'] . '/' . basename( str_replace(" ","",$row[27])));die;
					$post_id = wp_insert_post(array(
					    'post_title' => $row[0],
					    'post_name' => $row[1],
					    'post_content' => $row[2],
					    'post_status' => $row[3],
					    'post_type' => 'property',
					), true);

					if(! is_wp_error($post_id)) {						
						update_post_meta( $post_id, 'contact_information_phone_number', $row[4] );
						update_post_meta( $post_id, 'contact_information_website_url', $row[5]);
						update_post_meta( $post_id, 'contact_information_licience', $row[6] );
						update_post_meta( $post_id, 'location_address', $row[7] );
						update_post_meta( $post_id, 'location_state', $row[8] );
						update_post_meta( $post_id, 'location_city', $row[9] );
						update_post_meta( $post_id, 'location_zip_code', $row[10] );


						update_post_meta( $post_id, 'contactInfo_phone_number', $row[4] );
						update_post_meta( $post_id, 'contactInfo_website_url', $row[5]);
						update_post_meta( $post_id, 'contactInfo_license', $row[6] );
						update_post_meta( $post_id, 'pro_location_address', $row[7] );
						update_post_meta( $post_id, 'pro_location_state', $row[8] );
						update_post_meta( $post_id, 'pro_location_city', $row[9] );
						update_post_meta( $post_id, 'pro_location_zip_code', $row[10] );

						$cat1 = trim($row[11]);					
						$cat2 = trim($row[12]);
						$cat3 = trim($row[13]);

						$cat_ids = [];
						$cat1_id = $this->insert_cat($cat1, 0);
						if($cat1_id) $cat_ids[] = $cat1_id;
						$cat2_id = $this->insert_cat($cat2, $cat1_id);
						if($cat2_id) $cat_ids[] = $cat2_id;

						wp_set_post_terms($post_id, $cat_ids, 'category');
					}				

					$allimages = explode("|",trim($row[14]));
                    $attarray = array();
					foreach($allimages as $imgname) {
						$attach_id = $this->multiple_gallery($imgname, $post_id);
						array_push($attarray, $attach_id);
					}
					set_post_thumbnail( $post_id, $attarray[0]);
					array_shift($attarray);					
					if(!empty($attarray)) {
					    update_post_meta($post_id, 'add_propertymedia', $attarray);
					    update_post_meta($post_id, 'vdw_gallery_id', $attarray);

					}					
					
				}

				fclose($file);
				$args = [
					'page' => 'property-importer',
				];
				$actionurl = add_query_arg($args, admin_url('admin.php'));
				wp_redirect($actionurl);
			 	die;
			}
		}
	}
	function Generate_Featured_Image( $image_url, $post_id  ){
	    $upload_dir = wp_upload_dir();
	    $image_data = file_get_contents($image_url);
	    $filename = basename($image_url);
	    if(wp_mkdir_p($upload_dir['path']))
	      $file = $upload_dir['path'] . '/' . $filename;
	    else
	      $file = $upload_dir['basedir'] . '/' . $filename;
	    file_put_contents($file, $image_data);

	    $wp_filetype = wp_check_filetype($filename, null );
	    $attachment = array(
	        'post_mime_type' => $wp_filetype['type'],
	        'post_title' => sanitize_file_name($filename),
	        'post_content' => '',
	        'post_status' => 'inherit'
	    );
	    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
	    require_once( ABSPATH . 'wp-admin/includes/image.php' );
				require_once( ABSPATH . 'wp-admin/includes/file.php' );
	  			require_once( ABSPATH . 'wp-admin/includes/media.php' );
	    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
	    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
	    return $attach_id;
	    //$res2= set_post_thumbnail( $post_id, $attach_id );
	}
	public function multiple_gallery($image_url, $post_id){
		//$image_url = 'adress img';

		$upload_dir = wp_upload_dir();

		$image_data = file_get_contents( $image_url );

		$filename = basename( $image_url );

		if ( wp_mkdir_p( $upload_dir['path'] ) ) {
		  $file = $upload_dir['path'] . '/' . $filename;
		}
		else {
		  $file = $upload_dir['basedir'] . '/' . $filename;
		}

		file_put_contents( $file, $image_data );

		$wp_filetype = wp_check_filetype( $filename, null );

		$attachment = array(
		  'post_mime_type' => $wp_filetype['type'],
		  'post_title' => sanitize_file_name( $filename ),
		  'post_content' => '',
		  'post_status' => 'inherit'
		);

		$attach_id = wp_insert_attachment( $attachment, $file );
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
		wp_update_attachment_metadata( $attach_id, $attach_data );
		return $attach_id;
	}
	public function insert_cat($name = '', $parent = 0) {
		$cats = get_terms('category', [
			'hide_empty' => false,
		]);

		$cat_id = 0;
		if(! empty($cats)) {
			foreach($cats as $cat) {
				if($cat->name == $name && $cat->parent == $parent) {
					$cat_id = $cat->term_id;
				}
			}
		}
		if((int) $cat_id == 0) {
			$arg = ['parent'=> $parent];

			$cat = wp_insert_term($name, 'category', $arg);
			//print_r($cat);
			if(! is_wp_error($cat)) {
				$cat_id = $cat['term_id'];
			} elseif(isset($cat->error_data['term_exists'])) {
				$cat_id = $cat->error_data['term_exists'];
			}
		}
		//echo $name . ' : ' . $cat_id . '<br/>';
		return $cat_id;
	}
}