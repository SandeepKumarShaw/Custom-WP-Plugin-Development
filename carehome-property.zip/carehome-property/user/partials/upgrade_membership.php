<?php
  /**
  * Provide a user-facing view for the plugin
  *
  * This file is used to markup the user-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/user/partials
  */ 
  ?>
<?php
  if( is_user_logged_in() ) {
  
  $user_details = new WP_User(get_current_user_id());
  $user_id = $user_details->ID;   
  $userPlan = get_user_meta( $user_id, 'property_upgrade_membership', true );
  $userPay = get_user_meta( $user_id, 'property_upgrade_membership_payment', true );
  $userPayName = get_user_meta( $user_id, 'property_upgrade_membership_payment_plan', true );
  $subscriber_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', true );
  $plan_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', true );
}  
  ?>
<div class="uk-container">
  <div class="uk-grid uk-grid-divider uk-grid-stack" uk-grid="">
    <div class="uk-width-expand@m uk-first-column">
      <section id="primary">
        <div id="content" role="main">
          <div class="jr-page jr-form-listing-outer jrPage jrListingCreate">
            <div class="jrAccountButtons jrClearfix"> <a href="<?php echo site_url() .'/your-listings/'; ?>" class="jrButton jrBlue jrAddListing jrRight"><span class="jrIconAddListing"></span>View All Listings</a></div>
            <form id="jr-form-listing" method="post" action="javascript:void(0);" data-listing-id="" data-cat-id="17">
              <div class="jr-form-listing-fields jrForm jrFormContainer jrHidden" style="display: block;">
                <fieldset>
                  <h2>Active Subscription Plan</h2>
                  <?php
                    if($subscriber_id == '0'){
                    
                    ?> 
                  <p> You have free plan Activated. Please subscribe from below plans...</p>
                  <?php }else{?> 
                    
                    <div id="update-success" class="hidden">
                      <i class="fa fa-check"></i>
                      <p>Upgrade Subscription Successfully!</p>
                    </div>
                      
                  <div class="jrDataList">
                    <div class="jr-paid-plan-row jrGrid" style="background-color: aqua;">
                      <div class="jrCol2">            
                      </div>
                      <div class="jrCol4">
                        <span class="jrPlanName"><strong><?php echo $userPayName;?></strong></span>            
                      </div>
                      <div class="jrCol3">
                        <div class="jrLeft">
                          <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo number_format($userPay,2); ?></span>
                        </div>
                      </div>
                      <div class="jrCol3">
                        <?php if($userPayName == 'Assisted Living Premium Monthly'){?>
                        <button class="jr-paid-buy jrButton jrSmall jr-paid-buy-sub" data-sub-id="<?php echo $subscriber_id; ?>" value="<?php echo $plan_id; ?>" onclick="updateSubPlan('<?php echo $plan_id; ?>','<?php echo $subscriber_id; ?>')">
                        <span class="jrIcon jrIconCart"></span>Upgrade
                        </button>
                        <!--             <input type="button" class="jr-paid-buy jrButton jrSmall jr-paid-buy-sub" value="one" id="One"/> 
                          -->
                        <?php } ?>
                      </div>
                    </div>
                    <br>
                  </div>
                  <?php } ?>
                </fieldset>
                <fieldset id="jr-paid-plan-list">
                  <h2>Available plans For Subscription:</h2>
                  <?php if($userPlan == 0 || $userPlan > 0){?>
                  <div class="jrDataList">
                    <div class="jrGrid jrDataListHeader">Free &amp; Trial Plans</div>
                    <div class="jr-paid-plan-row jrGrid" style="background-color: rgb(225, 225, 225);">
                      <div class="jrCol1">
                        <input name="jr_paid_plan1" type="radio" value="1" data-free="1" disabled>
                      </div>
                      <div class="jrCol3">
                        <span class="jrPlanName"><strong>Free</strong></span>
                        <span class="jrPlanDuration">
                        Never expires
                        </span>
                      </div>
                      <div class="jrCol6">
                        The free plan allows you to add your care home(s) with a basic description, location and contact information.  
                        &nbsp;
                      </div>
                      <div class="jrCol2">
                        <div class="jrRight">
                          <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice">0.00</span>
                        </div>
                      </div>
                    </div>
                    <br>
                  </div>
                  <?php } ?>
                  <?php
                    require_once plugin_dir_path( dirname( __FILE__ ) ) . '/vendor/autoload.php';
                    
                      $stripeOption = get_option( 'stripepayments_settings_option_name' ); 
                      $livemode = $stripeOption['is_live_0'];
                      if(isset($livemode) && $livemode === 'is_live_0'){
                         $publishable_key = $stripeOption['api_publishable_key_1'];
                         $secret_key      = $stripeOption['api_secret_key_2'];
                      }else{
                         $publishable_key = $stripeOption['api_publishable_key_test_3'];
                         $secret_key      = $stripeOption['api_secret_key_test_4'];
                      }
                      $stripe = [
                        "secret_key"      => $secret_key,
                        "publishable_key" => $publishable_key,
                    ];
                    
                    \Stripe\Stripe::setApiKey($stripe['secret_key']);
                    $Plans = \Stripe\Plan::all();
                    foreach ($Plans['data'] as $plan) {
                      $price = $plan['amount'] / 100;
                    
                      if($userPay === '0'){?>
                  <div class="jrDataList">
                    <div class="jrGrid jrDataListHeader">Subscription Plans</div>
                    <div class="jr-paid-plan-row jrGrid">
                      <div class="jrCol1">
                        <input class="jr_paid_plan" name="jr_paid_plan" type="radio" value="<?php echo $plan['id'];?>" data-AmtPrice="<?php echo $plan['amount'] / 100; ?>" data-interval="<?php echo $plan['interval'];?>" data-nickname="<?php echo $plan['nickname'];?>">
                      </div>
                      <div class="jrCol3">
                        <span class="jrPlanName"><strong><?php echo $plan['nickname'];?></strong></span>
                        <span class="jrPlanDuration">
                        1
                        Month(s)
                        </span>
                      </div>
                      <div class="jrCol6">
                        The Assistsed Living Premium monthly plan provides featured placement in our search results and allows for a detailed overview of your care facility as well as pricing and availability of your shared and private rooms. You can also add up to 10 pictures and a YouTube or Vimeo video! 
                        &nbsp;
                      </div>
                      <div class="jrCol2">
                        <div class="jrRight">
                          <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo number_format($price,2); ?></span>
                        </div>
                      </div>
                    </div>
                    <br>
                  </div>
                  <?php }else{?>
                  <div class="jrDataList">
                    <div class="jrGrid jrDataListHeader">Subscription Plans</div>
                    <div class="jr-paid-plan-row jrGrid" style="background-color: rgb(225, 225, 225);">
                      <div class="jrCol1">
                        <input class="jr_paid_plan" name="jr_paid_plan" type="radio" value="<?php echo $plan['id'];?>" data-AmtPrice="<?php echo $plan['amount'] / 100; ?>" data-interval="<?php echo $plan['interval'];?>" data-nickname="<?php echo $plan['nickname'];?>" disabled>
                      </div>
                      <div class="jrCol3">
                        <span class="jrPlanName"><strong><?php echo $plan['nickname'];?></strong></span>
                        <span class="jrPlanDuration">
                        1
                        Month(s)
                        </span>
                      </div>
                      <div class="jrCol6">
                        The Assistsed Living Premium monthly plan provides featured placement in our search results and allows for a detailed overview of your care facility as well as pricing and availability of your shared and private rooms. You can also add up to 10 pictures and a YouTube or Vimeo video! 
                        &nbsp;
                      </div>
                      <div class="jrCol2">
                        <div class="jrRight">
                          <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo number_format($price,2); ?></span>
                        </div>
                      </div>
                    </div>
                    <br>
                  </div>
                  <?php } } ?> 
                </fieldset>
                <?php




                ?>
                <fieldset>
                  <div id="form-container-payment" style="display: none;">
                    <div id="card-success" class="hidden">
                      <i class="fa fa-check"></i>
                      <p>Payment Successful!</p>
                    </div>
                    <div id="form-errors" class="hidden">
                      <i class="fa fa-exclamation-triangle"></i>
                      <p id="card-error">Card error</p>
                    </div>
                    <div id="form-container">
                      <div id="card-front">
                        <label for="card-number">
                        Card Number
                        </label>
                        <input type="text" id="card-number" placeholder="1234 5678 9101 1112" maxlength="16">
                        <div id="cardholder-container">
                          <label for="card-holder">Card Holder
                          </label>
                          <input type="text" id="card-holder" placeholder="e.g. John Doe" />
                        </div>
                        <!--- end card holder container --->
                        <div id="exp-container">
                          <label for="card-exp">Expiration</label><br>
                          <input id="card-month" type="text" placeholder="MM" maxlength="2">
                          <input id="card-year" type="text" placeholder="YY" maxlength="2">
                        </div>
                        <div id="cvc-container">
                          <label for="card-cvc"> CVC/CVV</label><br>
                          <input id="card-cvc" placeholder="XXX-X" type="text" maxlength="4">
                          <p>Last 3 or 4 digits</p>
                        </div>
                      </div>
                      <!--- end card back --->
                      <input type="text" id="card-token" />
                      <button type="button" id="card-btn">Pay Now</button>
                    </div>
                  </div>
                  <!--- end form container --->
                  <div id="loader"></div>

                </fieldset>
              </div>
            </form>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
<?php
  echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
          </script>';
  
  ?>
  <style type="text/css">
    #loader {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      width: 100%;
      background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/carehome-property/user/images/loader1.gif'; ?>') no-repeat center center;
      z-index: 10000;
    }
  </style>
