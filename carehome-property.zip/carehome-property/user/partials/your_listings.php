<?php
  /**
  * Provide a user-facing view for the plugin
  *
  * This file is used to markup the user-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/user/partials
  */ 
  ?>
<div id="tm-main" class="tm-main uk-section uk-section-default" uk-height-viewport="expand: true" style="min-height: 113px;">
  <div class="uk-container">
    <div class="uk-grid uk-grid-divider uk-grid-stack" uk-grid="">
      <div class="uk-width-expand@m uk-first-column">
        <section id="primary">
          <div id="content" role="main">
            <div id="jr-paid-myaccount" class="jr-page jrPage jrMyAccount">
              <div class="jrAccountTabs">
                <div class="jrAccountButtons jrClearfix"> <a href="<?php echo site_url().'/add-your-care-home-property/';?>" class="jrButton jrBlue jrAddListing jrRight"><span class="jrIconAddListing"></span>Add new listing</a></div>
                <div class="jr-tabs-myaccount jr-main jrTabs fwd-mt-4 ui-tabs ui-corner-all ui-widget ui-widget-content">
                  <ul role="tablist" class="ui-tabs-nav ui-corner-all ui-helper-reset ui-helper-clearfix ui-widget-header tabs">
                    <li role="tab" tabindex="0" class="tab ui-tabs-tab ui-corner-top ui-state-default ui-tab ui-tabs-active ui-state-active" aria-controls="ui-id-2" aria-labelledby="ui-id-1" aria-selected="true" aria-expanded="true" data-tab="tab-1"><a href="javascript:void(0);" role="presentation" tabindex="-1" class="ui-tabs-anchor" id="ui-id-1">Listings</a></li>
                    <li role="tab" tabindex="-1" class="tab ui-tabs-tab ui-corner-top ui-state-default ui-tab" aria-controls="ui-id-8" aria-labelledby="ui-id-7" aria-selected="false" aria-expanded="false" data-tab="tab-2"><a href="javascript:void(0);" role="presentation" tabindex="-1" class="ui-tabs-anchor" id="ui-id-7">Active Subscriptions</a></li>
                  </ul>
                  <div id="tab-1" class="tab-content ui-state-active">
                    <div id="jr-listings-table" class="jr-page-inner jrMyAccountListings">
                      <form id="jr-listings-form" name="jr-listings-form" type="post" action="#">
                        <div class="jrDataList">
                          <div class="jrGrid jrDataListHeader">
                            <div class="jrCol5">Details</div>
                            <div class="jrCol5">Featured</div>
                            <div class="jrCol2">Action</div>
                          </div>
                          <?php 
                            $user_details = new WP_User(get_current_user_id());
                            $user_id = $user_details->ID; 
                            
                            
                            global $wp_query, $wpdb, $post, $page;
                            $count = $wpdb->get_var("SELECT COUNT(ID) FROM ".$wpdb->prefix."posts WHERE post_author = '" . $user_id . "' AND post_type = 'property' AND post_status = 'publish'");
                            
                            
                            
                            $per_page = 4;
                            $paged = get_query_var('paged') ? get_query_var('paged') : 1;
                            $args['post_type'] = 'property';
                            $args['posts_per_page'] = $per_page;
                            $args['author'] = $user_id;
                            $args['orderby'] = 'post_date';
                            $args['order'] = 'ASC';
                            $args['post_status'] = 'publish';
                            $args['paged'] = $paged;
                            
                            //print_r($args);
                            
                            $loop = new WP_Query( $args );
                            $from = ($per_page * $paged) - ($per_page - 1);
                            
                            if(($per_page * $paged) <= ($loop->found_posts)){
                              $to = ($per_page * $paged);
                            }else{
                              $to = $loop->found_posts;
                            }
                            if($from == $to){
                              $from_to = $from;
                            }else{
                              $from_to = $from . ' - ' . $to;
                            } 
                            if ( $loop->have_posts() ) : ?>
                          <?php 
                            // Start the Loop.
                            while ( $loop->have_posts() ) :
                                $loop->the_post(); 
                            
                               // echo $post->ID;
                            //$is_featured = get_post_meta($post->ID, '_is_featured', TRUE);    
                            ?>
                          <div class="jr-layout-outer jrGrid">
                            <div class="jrCol1"></div>
                            <div class="jrCol5 fwd-flex fwd-flex-row">
                              <div class="fwd-mr-2">
                                <?php
                                  if(has_post_thumbnail() ) :
                                  $image_id = get_post_thumbnail_id($post->ID);          
                                  $src = wp_get_attachment_image_src($image_id, array( 5600,1000 ), false, '' );  
                                  $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);          
                                  ?>
                                <a href="<?php echo get_the_permalink($post->ID); ?>"><img src="<?php echo $src[0];?>" class="fwd-w-12 fwd-h-12 fwd-object-cover fwd-rounded" alt="<?php echo $image_alt;?>"></a> 
                                <?php
                                  else:
                                  ?>
                                <a href="<?php echo get_the_permalink($post->ID); ?>"><img src="<?php echo plugins_url();?>/carehome-property/public/images/chd_white-bg-temp_image.png" class="fwd-w-12 fwd-h-12 fwd-object-cover fwd-rounded" alt="Cameo Assisted Living - Lighthouse"></a>
                                <?php
                                  endif;
                                  ?> 
                              </div>
                              <div class="">
                                <a href="<?php echo get_the_permalink($post->ID); ?>"><?php echo get_the_title(); ?></a>
                                <span class="jrStatusIndicators">
                                </span>
                                <div>
                                  <?php
                                    $category = get_the_category();
                                    if($category){
                                      $firstCategory = $category[0]->cat_name;
                                      $cat_slug = $category[0]->category_nicename;
                                      if(!empty($firstCategory)){  
                                        echo $firstCategory . '<br>';
                                      } 
                                    }
                                    ?>
                                </div>
                              </div>
                            </div>
                            <div class="jrCol3">
                              <?php 
                                $is_featured = get_post_meta($post->ID, '_is_featured', TRUE);  
                              if($is_featured):?>
                              <span class="jrStatusIndicators">
                              <span title="" class="jrStatusLabel jrStatusFeatured jrBlue">Featured</span>
                              </span>
                              <?php else: ?>
                                <span class="jrStatusIndicators">
                              <span title="" class="jrStatusLabel jrStatusFeatured jrWhite">Not Featured</span>
                              <?php endif; ?>
                            </div>
                            <?php
                              $edit_post = site_url() .'/update-property/?post=' . $post->ID;
                              ?>
                            <div class="jrCol3 jrRightAlign">
                              <a href="<?php echo $edit_post; ?>" title="">Edit</a> | <a href="javascript:void(0);" title="" onclick="delProperty('<?php echo $post->ID;?>')">Delete</a>
                            </div>
                          </div>
                          <?php
                            endwhile;
                            //wp_reset_postdata();        
                            // If no content, include the "No posts found" template.
                            else :
                            echo "No Post Found"; 
                            endif;
                            ?>
                        </div>
                        <div class="jr-pagenav jrTableGrid jrPagination jrPaginationBottom" data-ajax="1" data-push="1">
                          <div class="jrCol4 jrPagenavResults">
                            <?php if($count > 0): ?>
                            <span class="jrPagenavResultsText"><?php echo $count; ?> results - showing <?php echo $from_to; ?></span>
                            <?php endif; ?>
                          </div>
                          <div class="jrCol4 jrPagenavPages">
                            <div class="jrButtonGroup fwd-flex-no-wrap"> 
                              <?php
                                $page_number_max = ceil($count / $per_page);
                                     // echo $page_number_max; 
                                        echo do_shortcode("[WP_Property_User_Archieve_shortcode pagerange=" . $page_number_max . "]"); 
                                        wp_reset_postdata();        
                                      ?>   
                            </div>
                          </div>
                          <div class="jrCol4 jrPagenavLimit">
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div id="tab-2" aria-live="polite" aria-labelledby="ui-id-9" role="tabpanel" class="tab-content" aria-hidden="false">
                    <div id="jr-payments-list" class="jr-page-inner jrMyAccountPayments">
                      <?php
                        $userPlan = get_user_meta( $user_id, 'property_upgrade_membership', true );
                        $userPay = get_user_meta( $user_id, 'property_upgrade_membership_payment', true );
                        $userPayName = get_user_meta( $user_id, 'property_upgrade_membership_payment_plan', true );
                        $subscriber_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_id', true );
                        $plan_id = get_user_meta( $user_id, 'property_upgrade_membership_subscriber_plan_id', true );                     
                                               
                        
                        ?>
                      <h2>Active Subscription Plan</h2>
                      <?php
                        if($subscriber_id == '0'){
                        
                        ?> 
                      <p> You have free plan Activated. Please subscribe from below plans...</p>
                      <?php }else{?> 
                      <div class="jrDataList">
                        <div class="jr-paid-plan-row jrGrid" style="background-color: aqua;">
                          <div class="jrCol2">            
                          </div>
                          <div class="jrCol4">
                            <span class="jrPlanName"><strong><?php echo $userPayName;?></strong></span>            
                          </div>
                          <div class="jrCol3">
                            <div class="jrLeft">
                              <span class="jrCurrencySymbol">$</span><span class="jrPlanPrice"><?php echo number_format($userPay,2); ?></span>
                            </div>
                          </div>
                          <div class="jrCol3">
                            <?php if($userPayName == 'Assisted Living Premium Monthly'){?>
                            <button class="jr-paid-buy jrButton jrSmall jr-paid-buy-sub" data-sub-id="<?php echo $subscriber_id; ?>" value="<?php echo $plan_id; ?>" onclick="updateSubPlan('<?php echo $plan_id; ?>','<?php echo $subscriber_id; ?>')">
                            <span class="jrIcon jrIconCart"></span>Upgrade
                            </button>
                            <!--             <input type="button" class="jr-paid-buy jrButton jrSmall jr-paid-buy-sub" value="one" id="One"/> 
                              -->
                            <?php } ?>
                          </div>
                        </div>
                        <br>
                      </div>
                      <?php } ?>
                    </div>
                    <div id="loader"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</div>
<?php
  echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
          </script>';
  
  ?>
<style type="text/css">
  #loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/carehome-property/user/images/loader1.gif'; ?>') no-repeat center center;
  z-index: 10000;
  }
</style>