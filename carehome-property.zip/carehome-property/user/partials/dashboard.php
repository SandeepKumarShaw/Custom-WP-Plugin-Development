<?php
  /**
  * Provide a user-facing view for the plugin
  *
  * This file is used to markup the user-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/user/partials
  */ 
  ?>
<div class="uk-section-default uk-section">
  <div class="uk-container">
    <div class="uk-margin uk-grid" uk-grid="">
      <div class="uk-width-expand@m uk-first-column">
        <div class="uk-alert">
          <h3 class="el-title">Welcome To Your Dashboard</h3>
          <div class="el-content">
            <p>Here on the dashboard you can access all of<br>your account features, benefits and settings.</p>
          </div>
        </div>
      </div>
      <div class="uk-width-expand@m">
        <div class="uk-alert">
          <h3 class="el-title">Get Started!</h3>
          <div class="el-content">
            <p><a href="<?php echo site_url().'/property-advanced-search/';?>">Click here to search</a> for care homes. You can also save your searches and favorites to help you find the right one!</p>
          </div>
        </div>
      </div>
    </div>
    <div class="uk-margin-large uk-grid uk-grid-stack" uk-grid="">
      <div class="uk-width-1-1@m uk-first-column">
        <div class="uk-margin">
          <div class="uk-child-width-1-1 uk-child-width-1-2@s uk-child-width-1-2@m uk-grid-medium uk-grid-match uk-grid" uk-grid="">

            <div class="uk-first-column">
              <div class="el-item uk-card uk-card-secondary uk-card-hover uk-card-body">
                <a class="el-link uk-position-cover uk-position-z-index uk-margin-remove-adjacent" href="<?php echo site_url();?>/wp-admin/profile.php"></a>
                <div class="uk-child-width-expand uk-grid" uk-grid="">
                  <div class="uk-width-1-4@m uk-first-column">
                    <span class="el-image uk-icon" uk-icon="icon: user; ratio: 4;">
                      <svg width="80" height="80" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" data-svg="user">
                        <circle fill="none" stroke="#000" stroke-width="1.1" cx="9.9" cy="6.4" r="4.4"></circle>
                        <path fill="none" stroke="#000" stroke-width="1.1" d="M1.5,19 C2.3,14.5 5.8,11.2 10,11.2 C14.2,11.2 17.7,14.6 18.5,19.2"></path>
                      </svg>
                    </span>
                  </div>
                  <div>
                    <h3 class="el-title uk-margin uk-card-title uk-margin-remove-adjacent"> Your Account</h3>
                    <div class="el-meta uk-margin uk-text-meta">For Everyone</div>
                    <div class="el-content uk-margin uk-text-lead">
                      <p>Change your name, username, email, password &amp; manage notifications.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div class="el-item uk-card uk-card-secondary uk-card-hover uk-card-body">
                <a class="el-link uk-position-cover uk-position-z-index uk-margin-remove-adjacent" href="<?php echo site_url().'/your-listings/';?>"></a>
                <div class="uk-child-width-expand uk-grid" uk-grid="">
                  <div class="uk-width-1-4@m uk-first-column">
                    <span class="el-image uk-icon" uk-icon="icon: home; ratio: 4;">
                      <svg width="80" height="80" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" data-svg="home">
                        <polygon points="18.65 11.35 10 2.71 1.35 11.35 0.65 10.65 10 1.29 19.35 10.65"></polygon>
                        <polygon points="15 4 18 4 18 7 17 7 17 5 15 5"></polygon>
                        <polygon points="3 11 4 11 4 18 7 18 7 12 12 12 12 18 16 18 16 11 17 11 17 19 11 19 11 13 8 13 8 19 3 19"></polygon>
                      </svg>
                    </span>
                  </div>
                  <div>
                    <h3 class="el-title uk-margin uk-card-title uk-margin-remove-adjacent"> Your Listings</h3>
                    <div class="el-meta uk-margin uk-text-meta">For Care Providers</div>
                    <div class="el-content uk-margin uk-text-lead">
                      <p>Add new, edit or delete your care home listing(s).&nbsp;</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="uk-grid-margin uk-first-column">
              <div class="el-item uk-card uk-card-secondary uk-card-hover uk-card-body">
                <a class="el-link uk-position-cover uk-position-z-index uk-margin-remove-adjacent" href="<?php echo site_url().'/upgrade-membership/';?>"></a>
                <div class="uk-child-width-expand uk-grid" uk-grid="">
                  <div class="uk-width-1-4@m uk-first-column">
                    <span class="el-image uk-icon" uk-icon="icon: heart; ratio: 4;">
                      <svg width="80" height="80" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" data-svg="heart">
                        <path fill="none" stroke="#000" stroke-width="1.03" d="M10,4 C10,4 8.1,2 5.74,2 C3.38,2 1,3.55 1,6.73 C1,8.84 2.67,10.44 2.67,10.44 L10,18 L17.33,10.44 C17.33,10.44 19,8.84 19,6.73 C19,3.55 16.62,2 14.26,2 C11.9,2 10,4 10,4 L10,4 Z"></path>
                      </svg>
                    </span>
                  </div>
                  <div>
                    <h3 class="el-title uk-margin uk-card-title uk-margin-remove-adjacent"> Upgrade Membership </h3>
                    <div class="el-meta uk-margin uk-text-meta">For Consumers</div>
                    <div class="el-content uk-margin uk-text-lead">
                      <p>Upgrade Your care homes Membership.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<!--             <div class="uk-grid-margin">
              <div class="el-item uk-card uk-card-secondary uk-card-hover uk-card-body">
                <a class="el-link uk-position-cover uk-position-z-index uk-margin-remove-adjacent" href="/cnp769/advanced-search/search-results/?saved"></a>
                <div class="uk-child-width-expand uk-grid" uk-grid="">
                  <div class="uk-width-1-4@m uk-first-column">
                    <span class="el-image uk-icon" uk-icon="icon: search; ratio: 4;">
                      <svg width="80" height="80" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" data-svg="search">
                        <circle fill="none" stroke="#000" stroke-width="1.1" cx="9" cy="9" r="7"></circle>
                        <path fill="none" stroke="#000" stroke-width="1.1" d="M14,14 L18,18 L14,14 Z"></path>
                      </svg>
                    </span>
                  </div>
                  <div>
                    <h3 class="el-title uk-margin uk-card-title uk-margin-remove-adjacent"> Your Searches</h3>
                    <div class="el-meta uk-margin uk-text-meta">For Consumers</div>
                    <div class="el-content uk-margin uk-text-lead">
                      <p>View the searches you've saved.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>  