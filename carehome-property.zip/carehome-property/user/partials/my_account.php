<?php
  /**
  * Provide a user-facing view for the plugin
  *
  * This file is used to markup the user-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/user/partials
  */ 
  ?>
  <?php

    $googlemap_capcha_api = get_option( 'googlemap_capcha_api_settings_option_name');
    $capchakey = $googlemap_capcha_api['recaptcha_site_key_0']; 
    if(isset($capchakey)){
      $key = $capchakey;
    }else{
      $key = '6Lf6VLAUAAAAAPqPJUEFT87XM6JWU4D3HOzyB1AA';
    }
  ?>

<div class="jr-page userprofiles-page jrUserProfilesSignup jrPage">
  <div class="jrGrid">
    <div class="jrCol4 jrUserProfilesLogin">
      <h3>Sign in to your account</h3>
      <form id="user-account-log-in" class="user-account-login jrForm" action="javascript:void(0);" method="post">

         <div id="log-success"></div>
        <div id="log-error"></div>

        <input type="hidden" name="ajaxUrl_action" id="pro_ajaxUrl_action" value="<?php echo admin_url('admin-ajax.php'); ?>">

        <input type="hidden" name="prop_redirect_to" id="prop_redirect_to" value="<?php echo site_url().'/welcome-dashboard-user/'; ?>">
        <input type="hidden" name="action" id="logaction" value="PropertyLoginProcess" />
        <div class="jrFieldDiv"> 
          <input class="jrText" placeholder="E-mail address" type="email" name="prop_wpmp_email1" id="prop_wpmp_email1">
        </div>
        <div class="jrFieldDiv"> 
          <input class="jrName" placeholder="Password" type="password" name="prop_wpmp_password1" id="prop_wpmp_password1">
        </div>
        <div class="jrFieldDiv"> 
          <button type="submit" class="jrButton jrLarge jrBlue">Sign in</button>
        </div>
        <div class="jrFieldDiv"> <a href="<?php echo site_url() . '/wp-login.php?action=lostpassword'; ?>">Forgot your password?</a></div>
      </form>
    </div>
    <div class="jrCol1">&nbsp;</div>
    <div class="jrCol1 jrAccountSignupSeparator">&nbsp;</div>
    <div class="jrCol5">
      <h3>Register for a new account</h3>
      <form id="user-account-register" class="jrForm" method="post" action="javascript:void(0);" onsubmit="return submitUserRegistrationForm();">
        <div id="reg-success"></div>
        <div id="reg-error"></div>
               <input type="hidden" name="ajaxUrl_action" id="pro_ajaxUrl_action_reg" value="<?php echo admin_url('admin-ajax.php'); ?>">

        <input type="hidden" name="prop_wpmp_current_url" id="prop_wpmp_current_url" value="<?php echo get_permalink(); ?>" />
        <input type="hidden" name="action" id="regaction" value="PropertyRegistrationProcess" />
        <input type="hidden" name="redirection_url" id="prop_redirection_url" value="<?php echo site_url().'/welcome-dashboard-user/'; ?>" />
        
        <div class="jrFieldDiv"> 
          <input class="jrName" placeholder="Your name" type="text" name="prop_wpmp_fname" id="prop_wpmp_fname">
        </div>
        <div class="jrFieldDiv"> 
          <input class="jr-email-check jrText" placeholder="E-mail address" type="email" name="prop_wpmp_email" id="prop_wpmp_email">
        </div>
        <div class="jrFieldDiv"> 
          <input class="jrName jr-password-check" placeholder="Password" type="password" name="prop_wpmp_password" id="prop_wpmp_password">
        </div>
        <div class="jrFieldDiv"> 
          <input type="password" name="prop_wpmp_password2" id="prop_wpmp_password2" placeholder="Re-type password" class="jrName">
        </div>
        <div class="jrFieldDiv"> 
          <input type="checkbox" class="" name="prop_wpmp_checkbox" id="prop_wpmp_checkbox" value="1">
          I agree to the <a href="<?php echo site_url(); ?>/terms-of-use">terms of use.</a> 
         
        </div>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

        <div class="jr-captcha jrCaptcha">

        <div class="g-recaptcha" data-sitekey="<?php echo $key; ?>" data-callback="recaptchaCallback"></div>

        <div id="google-recaptcha-error"></div>
        </div>
        <input type="hidden" class="hiddenRecaptcha required" name="hiddenRecaptcha" id="hiddenRecaptcha">


        <div class="jrFieldDiv"> <button class="account-create-submit jrButton jrLarge jrGreen">Register new account</button></div>
      </form>
    </div>
  </div>
</div>
<div id="loader"></div>

<style type="text/css">
  #loader {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
  background: rgba(0,0,0,0.75) url('<?php echo plugins_url() . '/carehome-property/user/images/loader1.gif'; ?>') no-repeat center center;
  z-index: 10000;
  }

</style>



