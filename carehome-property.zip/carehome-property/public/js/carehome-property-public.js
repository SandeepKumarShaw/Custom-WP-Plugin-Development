jQuery(document).ready(function(){
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	        /*--------Tab scroll----------------*/

	 		jQuery('a.jumpLink').click(function(){
				//alert('hi');
				if ( jQuery(jQuery(this).attr('data-selector')).length ){
					jQuery(jQuery(this).attr('data-selector')).jrScrollTo({duration:200, offset:-20});
				}
			});

			/*------contact form ajax submit----*/
			jQuery('.inquiryButton').click(function(){

				//alert(ajaxurl);
				// jQuery('.formValidation').html('');
				var jr_name = $('#jr-inquiry-from_name').val();
				var jr_phn = $('#jr-inquiry-phone').val();
				var jr_email = $('#jr-inquiry-from_email').val();
				var jr_msg = $('#jr-inquiry-message').val(); 
				var jr_auth_mail = $('#authorEmail').val();
				var jr_listingName = $('#listingName').val();
				
				// var a = jQuery('.jrName').val();
				// alert(a);
				if ( jr_name == "" ){
					jQuery('.formValidation').html('Please enter your name.');
				} else if ( jr_phn == "" ){
					jQuery('.formValidation').html('Please enter your phone number.');
				} else if ( jr_email == "" ){
					jQuery('.formValidation').html('Please enter your email.');
				} else if ( jr_msg == "" ){
					jQuery('.formValidation').html('Please enter your message.');
				} else {		

				    jQuery.ajax({
				        url: ajaxurl, // or example_ajax_obj.ajaxurl if using on frontend
				        data: {
				            'action': 'contact_send_ajax_request',
				            'name' : jr_name,
				            'jr_phn' : jr_phn,
				            'jr_email' : jr_email,
				            'jr_msg' : jr_msg,
				            'authorMail' : jr_auth_mail,
				            'listingName' : jr_listingName
				        },
				        success:function(data) {
				           jQuery('.formValidation').html(data);
							document.getElementById('jr-inquiry-from_name').value ="";
							document.getElementById('jr-inquiry-phone').value ="";
							document.getElementById('jr-inquiry-from_email').value ="";
							document.getElementById('jr-inquiry-message').value ="";
				        },
				        error: function(errorThrown){
				            console.log(errorThrown);
				        }
				    });
				
				}
				// jQuery('#sendInquiry').click();
			});			
			jQuery('.shareIcon').click(function(){
				jQuery('.socialBookmarksVertical').jrScrollTo({duration:200, offset:-20});
			});	



});


/*(function (d, a) {
var h = d.getElementsByTagName("head")[0], p = d.location.protocol, s;
wl_ef_uid = a;
s = d.createElement("script");
s.type = "text/javascript";
s.charset = "utf-8";
s.async = true;
s.defer = true;
s.src = "//app.3ng.io/js/ef_embed.min.js";
h.appendChild(s);
})(document, '27703');*/



/* <![CDATA[ */
var s2AjaxUri = "/wp-admin/admin-ajax.php?action=jreviews_ajax",
jreviews = jreviews || {};
jreviews.cms = 2;
jreviews.relpath = "/carehomesdirect";
jreviews.calendar_img = "/carehomesdirect/wp-content/plugins/jreviews/jreviews/views/themes/default/theme_images/calendar.png",
jreviews.lang = jreviews.lang || {};
jreviews.qvars = {"pg":"pg","mc":"mc"};
jreviews.locale = "en_US";
jreviews.fb = {"appid":"","og":"1","xfbml":false};
jreviews.comparison = {
numberOfListingsPerPage: 3,
maxNumberOfListings: 15,
compareURL: "/carehomesdirect/compare/?id=listing_ids"
};
jreviews.mobi = 0;
jreviews.iOS = 0;
jreviews.isRTL = 0;
/* ]]> */
/* <![CDATA[ */
/*jreviews.geomaps = jreviews.geomaps || {};
jreviews.geomaps.autocomplete = true;
jreviews.geomaps.autocomplete_country = "";
jreviews.geomaps.mapData = {};
jreviews.geomaps.fields = {};
jreviews.geomaps.fields.mapit = "jr_address";
jreviews.geomaps.fields.proximity = "";
jreviews.geomaps.fields.lat = "jr_latitude";
jreviews.geomaps.fields.lon = "jr_longitude";
jreviews.geomaps.fields.default_country = "USA";
jreviews.geomaps.fields.address = {};
jreviews.geomaps.fields.address['address1'] = 'jr_address';
jreviews.geomaps.fields.address['city'] = 'jr_city';
jreviews.geomaps.fields.address['state'] = 'jr_state';
jreviews.geomaps.fields.address['postal_code'] = 'jr_postalcode';*/
/* ]]> */
