<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public
 */
class Carehomesdirect_Property_Archieve_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}
	public function get_property_template( $archive_template ) {
	     global $post;

	     if ( is_post_type_archive ( 'property' ) ) {
	          $archive_template = plugin_dir_path( __FILE__ ) . '/partials/property-template.php';
	     	//$archive_template = plugin_dir_path( __FILE__ ) . '/partials/single-property.php';
	     }
	     return $archive_template;
	}
	public function property_meta_query_page( $query ) {		
		// do not modify queries in the admin
		if( is_admin() ) {			
			return $query;			
		}			
		// only modify queries for 'event' post type
		if( isset($query->query_vars['post_type']) && $query->query_vars['post_type'] == 'property' ) {		
			$query->set( 'posts_per_page', 10 );	
			if( isset($_GET['jrTitle']) && $_GET['jrTitle'] !=''){
				$query->set( 'title', $_GET['jrTitle'] );
			}else{

			}
			$queryParamsCounter = 0;
			$filter = array();
			if ($queryParamsCounter > 1) {
			//$filter['relation'] = 'OR';
			}
			if( isset($_GET['jr_amenities'])){
				$queryParamsCounter++;
				$filter['relation'] = 'OR';
				foreach($_GET['jr_amenities'] as $jr_amenities) {
					$filter[] = array(
						'key' => 'amenities',
						'value' => $jr_amenities,
						'compare' => 'LIKE'
					);
				}
			}
			if( isset($_GET['jr_languagesspoken'])){
				$queryParamsCounter++;
				$filter['relation'] = 'OR';
				foreach($_GET['jr_languagesspoken'] as $jr_languagesspoken) {
					$filter[] = array(
						'key' => 'languages_spoken',
						'value' => $jr_languagesspoken,
						'compare' => 'LIKE'
					);
				}
			}
			if( isset($_GET['jr_services'])){
				$queryParamsCounter++;
				$filter['relation'] = 'OR';
				foreach($_GET['jr_services'] as $jr_services) {
					$filter[] = array(
						'key' => 'jr_services',
						'value' => $jr_services,
						'compare' => 'LIKE'
					);
				}
			}	
			if( isset($_GET['jr_city'])){
				$queryParamsCounter++;
				$filter['relation'] = 'OR';
				foreach($_GET['jr_city'] as $jr_city) {
				$jr_city1 = strtoupper(str_replace("-"," ",$jr_city));
					$filter[] = array(
						'key' => 'pro_location_city',
						'value' => $jr_city1,
						'compare' => 'LIKE'
					);
				}
			}	
			if( isset($_GET['jr_availbedprooms'])){
				$queryParamsCounter++;
				$filter[] = array(
					'key' => 'private_rooms',
					'value' => $_GET['jr_availbedprooms'],
					'type'		=> 'NUMERIC',
					'compare' => $_GET['jr_availbedprooms_c']
				);
			}
			if( isset($_GET['jr_availbedsrooms'])){
				$queryParamsCounter++;
				$filter[] = array(
					'key' => 'shared_rooms',
					'value' => $_GET['jr_availbedsrooms'],
					'type'		=> 'NUMERIC',
					'compare' => $_GET['jr_availbedsrooms_c']
				);
			}			
			if( isset($_GET['jr_privateroomcostmonth'])){
				$queryParamsCounter++;
				$filter[] = array(
					'key' => 'private_room_costmonth',
					'value' => $_GET['jr_privateroomcostmonth'],
					'type'		=> 'NUMERIC',
					'compare' => $_GET['jrPrivateroomcostmonth_c']
				);
			}
			if( isset($_GET['jr_sharedroomcostmonth'])){
				$queryParamsCounter++;
				$filter[] = array(
					'key' => 'shared_room_costmonth',
					'value' => $_GET['jr_sharedroomcostmonth'],
					'type'		=> 'NUMERIC',
					'compare' => $_GET['jrSharedroomcostmonth_c']
				);
			}
			if( isset($_GET['jr_postalcode'])){
				$queryParamsCounter++;
				$filter[] = array(
					'key' => 'pro_location_zip_code',
					'value' => $_GET['jr_postalcode'],
					'type'		=> 'NUMERIC',
					'compare' => '='
				);
			}
			if( isset($_GET['jv_category'])){
				$queryParamsCounter++;
		        $tax_query = array(
			        array(
			            'taxonomy' => 'category',
			            'terms' => $_GET['jv_category'],
			            'field' => 'slug',
			        ),
			    );
			    $query->set('tax_query', $tax_query);
			}
			if( isset($_GET['keywords'])){
				//$query->set( 'title', $_GET['keywords'] );
				$queryParamsCounter++;
					$filter[] = array(
					'relation' => 'OR',
				/*	array(
			            'key' => 'title',
			            'value' => $_GET['keywords'],
			            'compare' => 'LIKE'
			          ),*/
					array(
						'key' => 'pro_location_city',
						'value' => $_GET['keywords'],
						'compare' => 'LIKE'
					),
					array(
						'key' => 'pro_location_zip_code',
						'value' => $_GET['keywords'],
						'type'		=> 'NUMERIC',
						'compare' => '='
					)		    
				);

			}
            //$query->set( 'tax_query', $taxquery );
			$query->set('meta_query',$filter);
			$query->set( 'orderby', 'meta_value');
			// allow the url to alter the query
			if( isset($_GET['meta_key']) ||  isset($_GET['orderby']) ||  isset($_GET['order'])){
			$query->set('meta_key', $_GET['meta_key']);
			$query->set('orderby', $_GET['orderby']);
			$query->set('order', $_GET['order']);				
			}			
		}			
		return $query;
	}
	public function alter_posts_where_clause( $where, \WP_Query $q ){
		global $wpdb;
		//var_dump($wp_query);
	    if ( ! is_admin() && $q->is_main_query() && $q->is_post_type_archive ( 'property' ) ) {
		    //global $wpdb;
		    if( isset($_GET['keywords'])){
		    $term = filter_var( trim( $_GET['keywords'] ), FILTER_SANITIZE_STRING, FILTER_NULL_ON_FAILURE );

		    if ( is_null( $term ) )
		        return $where;
		    $term = $wpdb->esc_like( $term );
		    // Append to the WHERE clause:
		    $where .= $wpdb->prepare( " OR {$wpdb->posts}.post_title LIKE '%s'", "%{$term}%" );
		    return $where;
		}
		}
	}
	// numbered pagination
	public function pagination($page) {
        $big = 999999999; 
        echo paginate_links(
            array(
	            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
	            'format' => '?paged=%#%',
	            'current' => max( 1, get_query_var('paged') ),
	            'total' => $page,
	            'prev_text'       => __('&laquo;'),
                'next_text'       => __('&raquo;')

	        )
        );

	}
	public function Property_Archieve_shortcode($atts){
		return $this->pagination($atts['pagerange']);
	}
	public function Property_Advanced_Search_shortcode(){
        require_once plugin_dir_path( __FILE__ ) . 'partials/form/advanced-form.php';
    }
    public function my_custom_redirect() {
    	 if ( is_post_type_archive ( 'property' ) ) {
	          $not_blank = array_filter($_GET, function($x) { return $x != ''; });  
	         // var_dump($not_blank);
			  $url = site_url() . '/properties/';  
			  if ($not_blank != $_GET) {
			    $query = http_build_query($not_blank);
			    ob_flush();
			    header('Location: ' . $url . "?$query") ;
			    //wp_redirect($url . "?$query" );
			    exit;
			  } 
		} 
    } 
    public function Property_Search_load_widget(){
    	require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-custom-search-post-widget.php';
    	register_widget( 'Custom_Post_Search_Widget' );
    }
    public function property_map_search_shortcode(){
    	require_once plugin_dir_path( __FILE__ ) . 'partials/property-map-search.php';
    }
    public function property_map_search_Ajax(){
    	global $wpdb;
		//var_dump($wp_query);

		$feature = $_GET['feature'];
		$location = $_GET['location'];
		$step = $_GET['step'];
		$radius = 100;

		if(!empty($step)){
			$limit = 250 * $step;
			$offste = 250 * ($step - 1);
		}else {
			$limit = 250;
			$offste = 0;
		}

		$qr1 = "SELECT cp.*";

		$qr2 = "SELECT COUNT(cp.ID)"; 

		$qry = " FROM cbd_posts AS cp 
			JOIN cbd_postmeta AS cpm ON cpm.post_id = cp.ID
			JOIN cbd_postmeta AS cpt ON cpt.post_id = cp.ID";

		$condition = " WHERE cp.post_type = 'property' AND cpm.meta_key = 'proerty_lat' AND cpt.meta_key = 'property_long'";

		if($feature == 'featured'){
			$qry .= " JOIN cbd_postmeta AS cpa ON cpa.post_id = cp.ID";
		}

		$qry .= $condition;

		if(!empty($location)){
			$qry .= " AND ( 3959 * acos( cos( radians(" . $location['lat'] . ") ) 
                        * cos( radians( cpm.meta_value ) ) 
                        * cos( radians( cpt.meta_value ) 
                        - radians(" . $location['lng'] . ") ) 
                        + sin( radians(" . $location['lat'] . ") ) 
                        * sin( radians( cpm.meta_value ) ) ) <= " . $radius . ")";
		}

		if($feature == 'featured'){
			$qry .= " AND cpa.meta_key = '_is_featured' AND cpa.meta_value = 'yes'";
			$qry .= " GROUP BY cp.ID";
		}elseif($feature == 'title'){
			$qry .= " GROUP BY cp.ID";
			$qry .= " ORDER BY cp.post_title ASC";
		}elseif($feature == 'rdate'){
			$qry .= " GROUP BY cp.ID";
			$qry .= " ORDER BY cp.post_date DESC";
		}elseif($feature == 'reviews'){
			$qry .= " GROUP BY cp.ID";
			$qry .= " ORDER BY cp.comment_count DESC";
		}else{
			$qry .= " GROUP BY cp.ID";
		}

		$cqry = $qr2.$qry;

		$totcount = $wpdb->get_results($cqry);

		$qrys = $qr1.$qry." LIMIT " . $limit;

		if($offste > 0){
			$qrys .= " OFFSET " . $offste;
		}

		// echo $qry; exit;
		$locations = $wpdb->get_results($qrys);

		foreach($locations as $k => $loc){
			$metaval = $wpdb->get_results("SELECT * FROM cbd_postmeta WHERE post_id = '".$loc->ID."'");
			// $taxonomies=get_taxonomies('','names');
			$cat = wp_get_post_terms($loc->ID,'category');
			$image_id = get_post_thumbnail_id($loc->ID);                
           // $img = wp_get_attachment_image_src($image_id, array( 5600,1000 ), false, '' ); 

			$img = get_the_post_thumbnail_url($loc->ID);
			if($img){
				$img_url = $img;
			}else{
				$img_url = plugins_url() . '/carehome-property/public/images/chd_white-bg-temp_image.png';
			}
			$frd = get_post_meta($loc->ID,'_is_featured',true);
			$lat = get_post_meta($loc->ID,'proerty_lat',true);
			$lng = get_post_meta($loc->ID,'property_long',true);
			$city = get_post_meta($loc->ID, 'pro_location_city', true);
			$cat = get_the_category($loc->ID);
			if(!empty($cat)){
				$locations[$k]->category_name = $cat[0]->name;
				//$locations[$k]->category_url = get_category_link($cat[0]->term_id);
				$locations[$k]->category_url = $cat[0]->slug;
			}else{
				$locations[$k]->category_name = '';
				$locations[$k]->category_url = '';
			}
			
			$locations[$k]->image = $img_url;
			$locations[$k]->lat = $lat;
			$locations[$k]->lng = $lng;
			if(!empty($city)){
				$part = explode('-', $city);
				$cnt = count($part);
				$city = '';
				foreach($part as $v){
					$city .= ucfirst($v);
					$cnt -= 1;
					if($cnt > 0){
						$city .= ' ';
					}
				}
			}
			$rating = do_shortcode('[comment_rating_display_rating postid="' . $loc->ID . '"]');
			if(!empty($rating) || $rating != ''){
				$locations[$k]->rating = $rating;

			}else{
				$html= "";
				$html .= '<div class="jrRatingStars">';
				$html .= '<div class="jrRatingStarsUser jrRatingsStyle2 jrRatingsOrange">';
				$html .= '<div style="width:0.00%;">&nbsp;</div>';
				$html .= '</div>';
				$html .= '</div>';
				$html .= '<span class="jrRatingValue"><span class="rating_count">(<span class="count">4</span>)</span></span>';
				$locations[$k]->rating = $html;
			}

		   

			$locations[$k]->city = $city;
			if(!empty($frd)){
				$locations[$k]->featured = $frd;
			}else{
				$locations[$k]->featured = 'no';
			}
		}
		echo json_encode(['location' => $locations, 'totcount' => count($totcount)]); die;
    }
}