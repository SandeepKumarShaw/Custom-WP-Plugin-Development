<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public/partials
 */
get_header(); ?>

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				// Nope, just load the regular template then:
            load_template(plugin_dir_path( __FILE__ ) . '/content/single-property-content.php');
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :					
                    echo '<div class="jrClear"></div>';
					//echo '<a href="#" ID="Leave_a_comment">Leave a Comment</a>';
					echo '<div id="userReviews">';
						echo '<div id="comment_form_wrapper">';
						    comments_template( '', true );
						echo '</div>';
					echo '</div>';
				endif;
			endwhile; // End of the loop.
			?>
		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->
<?php
get_footer();