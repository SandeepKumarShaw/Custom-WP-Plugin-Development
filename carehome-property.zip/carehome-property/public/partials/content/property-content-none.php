<?php
	/**
	 * Provide a public-facing view for the plugin
	 *
	 * This file is used to markup the public-facing aspects of the plugin.
	 *
	 * @link       http://example.com
	 * @since      1.0.0
	 *
	 * @package    Carehome_Property
	 * @subpackage Carehome_Property/public/partials/content
	 */
?>
<div class="jrResults">
  <div id="jr-listing-column" class="jrListingColumn jrListColumn2">
  	<p> Your search did not return any results. Try adjusting your search values.</p>
  	<a href="javascript:window.history.go(-1)">Click here to go back.</a>
  </div>
  <div id="jr-map-column" class="jrMapColumn" style="width: 300px;">
  	<?php echo do_shortcode('[the_ad id="23311"]'); ?>
  	<br>
    <div id="jr-map-column1" class="jrMapColumn1" style="width: 300px;"></div>
  </div>
  <br><br><br><br><br><br><br>
</div>  