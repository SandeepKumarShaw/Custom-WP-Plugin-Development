<?php
    /**
     * Provide a public-facing view for the plugin
     *
     * This file is used to markup the public-facing aspects of the plugin.
     *
     * @link       http://example.com
     * @since      1.0.0
     *
     * @package    Carehome_Property
     * @subpackage Carehome_Property/public/partials/content
     */
    ?>
<div id="jr-map-column" class="jrMapColumn" style="width: 300px;">
    <?php
        $paged = get_query_var('paged') ? get_query_var('paged') : 1;
          $args = array('post_type' => 'property', 'posts_per_page' => -1, 'paged' => $paged);
          $loop = new WP_Query( $args );
        
              // Start the Loop.
              while ( $loop->have_posts() ) :
                  $loop->the_post(); 
        
        $pro_location_address = get_field( 'pro_location_address', $post->ID );
        $pro_location_city = get_field( 'pro_location_city', $post->ID );
        $pro_location_state = get_field( 'pro_location_state', $post->ID );
        $pro_location_zip_code = get_field( 'pro_location_zip_code', $post->ID );

        $googlemap_capcha_api = get_option( 'googlemap_capcha_api_settings_option_name');
        $Mapkey = $googlemap_capcha_api['google_maps_api_browser_key_2']; 
        if(isset($Mapkey)){
          $mapApiKey = $Mapkey;
        }else{
          $mapApiKey = 'AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ';
        }        
        $latLong = '';
        $address = $pro_location_address .',' . $pro_location_city . ',' . $pro_location_state . ',' . $pro_location_zip_code;

        
        $prepAddr = str_replace(' ','+',$address);
        $geocode=file_get_contents('https://maps.google.com/maps/api/geocode/json?address='.$prepAddr.'&key=' . $mapApiKey);
        $output= json_decode($geocode);
        $latitude = $output->results[0]->geometry->location->lat;
        $longitude = $output->results[0]->geometry->location->lng;
        
        $latLong .=  '[' . "'" .$pro_location_address ."'," . $latitude . ',' .$longitude . ']';
        $latLongArray[] = $latLong;
        $rating = do_shortcode('[comment_rating_display_rating postid="' . $post->ID . '"]');
        
        
        
              
        $html= "";
        $html .= '<div class="jrInfowindow" style="font-size: 10px;white-space: normal;word-wrap: break-word; background: #fff;text-align: left;">';
            $html .= '<div class="jrMapListing" style="color: #fff;text-decoration: none!important;">';
                $html .= '<div class="jrListingPhotoContent">';            
                        if(has_post_thumbnail() ) :
                        $image_id = get_post_thumbnail_id($post->ID);                
                        $src = wp_get_attachment_image_src($image_id, array( 5600,1000 ), false, '' );  
                        $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);
                        $html .= '<div class="jrListingPhotoWrapper" style="background-image: url(' . $src[0] . ');">';                
                            else:                  
                        $html .= '<div class="jrListingPhotoWrapper" style="background-image: url(" .plugins_url() . "/carehome-property/public/images/chd_white-bg-temp_image.png);">';                   
                                endif;                      
                            $html .= '<div class="jr-listing-thumbnail jrListingPhoto" data-id="21650">';
                                $html .= '<div class="jrOverallRatings">';
                                    $html .= '<div class="jrOverallUser" title="" user="" rating="">';
                                        $html .= '<span class="jrIconUsers jrRatingLabel"></span>';
                                       if($post->comment_count > 0):      
                                           $html .= "'.$rating.'";
                                        else:
                                        $html .= '<div class="jrRatingStars">';
                                            $html .= '<div class="jrRatingStarsUser jrRatingsStyle2 jrRatingsOrange">';
                                                $html .= '<div style="width:0.00%;">&nbsp;</div>';
                                            $html .= '</div>';
                                        $html .= '</div>';
                                        $html .= '<span class="jrRatingValue"><span class="rating_count">(<span class="count">4</span>)</span></span>';
                                   endif;                                
                                    $html .= '</div>';
                                $html .= '</div>';
                                $html .= '<div class="jrListingContent">';
                                    $html .= '<div class="jrMapListingTitle"><a href="' .  get_the_permalink($post->ID) . '">' . get_the_title($post->ID) . '</a></div>';
                                    $html .= '<div class="jrMapListingAuthor">';
                                    $html .= '</div>';
                                    $html .= '<div class="jrCustomFields">';
                                        $html .= '<div class="jrFieldGroup">';
                                            $html .= '<div class="jrFieldRow">';
                                                $html .= '<div class="jrFieldValue"><a href="">RANCHO MISSION VIEJO</a></div>';
                                            $html .= '</div>';
                                        $html .= '</div>';
                                    $html .= '</div>';
                                $html .= '</div>';
                            $html .= '</div>';
                        $html .= '</div>';
                    $html .= '</div>';
                $html .= '</div>';
            $html .= '</div>';
        $html .= '</div>';
        $property[][] = $html;



        
              
        endwhile;
        $latLongJSON = json_encode($latLongArray);
        $latLongstr = str_replace('"', '', $latLongJSON);
        ?>
   
<?php //echo do_shortcode('[the_ad id="23311"]'); ?>
<?php if(function_exists('the_ad')) the_ad(23311); ?>

    <br>
    <div id="jr-map-column1" class="jrMapColumn1" style="width: 300px;">
        <div id="jr-map-results-wrapper" class="jrMapResultsWrapper">
            <div class="jr-map-resize jrMapResize"> 
                <a href="javascript:void(0);" class="jr-map-large">« Large Map</a> 
            </div>
            <div class="jr-map-canvas jrMapList">
                <div id="map_wrapper">
                    <div id="map_canvas" class="mapping"></div>
                </div>
                <script type="text/javascript">
                    var propertyData = <?php echo json_encode($property); ?>;
                    
                    var latLongstr1 = <?php echo $latLongstr; ?>;
                    jQuery(function($) {
                    $('.jr-map-large').click( function() {
                        $(this).text($(this).text() == '« Large Map' ? 'Small Map »' : '« Large Map');
                    
                        var toggleWidth = $(".jrMapColumn1").width() == 300 ? "600px" : "300px";
                        var toggleWidth1 = $("#jr-map-results-wrapper").width() == 300 ? "600px" : "300px";
                        var toggleWidth2 = $(".jrMapResize").width() == 300 ? "600px" : "300px";
                         var toggleWidth3 = $(".jrMapList").width() == 300 ? "600px" : "300px";
                         var toggleWidth4 = $(".jrMapList").height() == 300 ? "500px" : "300px";
                    
                         var toggleWidth5 = $("#map_wrapper").height() == 300 ? "500px" : "300px";
                    
                    
                        $('.jrMapColumn1').animate({ width: toggleWidth });
                        $('#jr-map-results-wrapper').animate({ width: toggleWidth1 });
                         $('.jrMapResize').animate({ width: toggleWidth2 });
                         $('.jrMapList').animate({ width: toggleWidth3,height: toggleWidth4 });
                         $('#map_wrapper').animate({ height: toggleWidth5 });
                    });
                    // Asynchronously Load the map API 
                    var script = document.createElement('script');
                    script.src = "//maps.googleapis.com/maps/api/js?v=quarterly&key=<?php echo $mapApiKey; ?>&language=en&libraries=places&callback=initialize";
                    document.body.appendChild(script);
                    });
                    
                    function initialize() {
                    var map;
                    var bounds = new google.maps.LatLngBounds();
                    var mapOptions = {
                        mapTypeId: 'roadmap'
                    };                    
                    // Display a map on the page
                    map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
                    map.setTilt(45);        
                    // Multiple Markers
                    var markers = latLongstr1;                        
                    // Info Window Content
                    var infoWindowContent = propertyData;
                        
                    // Display multiple markers on a map
                    var infoWindow = new google.maps.InfoWindow(), marker, i;
                    
                    // Loop through our array of markers & place each one on the map  
                    for( i = 0; i < markers.length; i++ ) {
                        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
                        bounds.extend(position);
                        marker = new google.maps.Marker({
                            position: position,
                            map: map,
                            title: markers[i][0]
                        });
                        
                        // Allow each marker to have an info window    
                        google.maps.event.addListener(marker, 'click', (function(marker, i) {
                            return function() {
                                infoWindow.setContent(infoWindowContent[i][0]);
                                infoWindow.open(map, marker);
                            }                  
                           
                    
                        })(marker, i));
                    
                        // Automatically center the map fitting all markers on the screen
                        map.fitBounds(bounds);
                    }
                    
                    google.maps.event.addListener(map, 'click', function() {
                                infoWindow.close();
                            });                  
                    
                    
                    // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
                    var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
                        this.setZoom(4);
                        google.maps.event.removeListener(boundsListener);
                    });
                    
                    
                    
                    }
                </script>
            </div>
        </div>
    </div>
</div>


