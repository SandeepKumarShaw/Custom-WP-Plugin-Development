<?php
	/**
	 * Provide a public-facing view for the plugin
	 *
	 * This file is used to markup the public-facing aspects of the plugin.
	 *
	 * @link       http://example.com
	 * @since      1.0.0
	 *
	 * @package    Carehome_Property
	 *  @subpackage Carehome_Property/public/partials/content
	 */
	?>
<div class="jr-page jr-layout-outer jr-listing-detail jrPage jrListingDetail jrFeatured" itemscope="" itemtype="http://schema.org/LocalBusiness" jstcache="0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<ul class="jrPathway jrClearfix" itemscope="" itemtype="https://schema.org/BreadcrumbList">
		<li itemprop="itemListElement" itemscope="" itemtype="https://schema.org/ListItem">
			<a itemprop="item" href="<?php echo site_url().'/properties/';?>">
			<span itemprop="name">Listings</span>
			</a>
			<meta itemprop="position" content="1">
		</li>
		<?php
			$category = get_the_category();
			if($category){
			$firstCategory = $category[0]->cat_name;
			$cat_slug = $category[0]->category_nicename;
			if(!empty($firstCategory)){		
			
			?>
		<li itemprop="itemListElement" itemscope="" itemtype="https://schema.org/ListItem">
			<a itemprop="item" href="<?php echo site_url() . '/properties/?jv_category=' . $cat_slug; ?>">
			<span itemprop="name"><?php echo $firstCategory; ?></span>
			</a>
			<meta itemprop="position" content="2">
		</li>
		<?php } } ?>
		<li><span><?php echo get_the_title( $post->ID ); ?></span></li>
	</ul>
	<div class="jrClear"></div>
	<div class="uk-card uk-card-default">
		<div class="headingContainer ">
			<h1 class="contentheading">
				<span itemprop="name"><?php echo get_the_title( $post->ID ); ?></span>
			</h1>
			<br>
			<div id="divlicence">
				<div class="jrFieldLabel">License#</div>
				<div class="jrFieldValue">
					<?php 
						$contactInfo_license = get_field( 'contactInfo_license', $post->ID );
						if($contactInfo_license):
							echo $contactInfo_license;
						endif;
						?>	
				</div>
			</div>
			<div class="pricingAvailability paLong" style="margin-right: 37px;">
				<div class="availabilityTitle">AVAILABLE ROOMS</div>
				<div class="availabilityDetails">
					<div class="availabilityTypeDetails privateRoom">
						<div class="availabilityRooms">
							<?php 
								$private_rooms = get_field( 'private_rooms', $post->ID );
								if($private_rooms):
									echo $private_rooms;
								endif;
								?>							
						</div>
						<div class="typeRooms">
							Private									
						</div>
						<?php 
							$private_room_costmonth = get_field( 'private_room_costmonth', $post->ID );
							if($private_room_costmonth):
							?>
						<div class="priceRooms">
							$<?php echo $private_room_costmonth; ?> /mo.
						</div>
						<?php endif; ?>
					</div>
					<div class="availabilityTypeDetails sharedRoom">
						<div class="availabilityRooms">
							<?php 
								$shared_rooms = get_field( 'shared_rooms', $post->ID );
								if($shared_rooms):
									echo $shared_rooms;
								endif;
								?>										
						</div>
						<div class="typeRooms">
							Shared									
						</div>
						<?php 
							$shared_room_costmonth = get_field( 'shared_room_costmonth', $post->ID );
							if($shared_room_costmonth):
							?>
						<div class="priceRooms">
							$<?php echo $shared_room_costmonth; ?> /mo.
						</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="jrClear"></div>
			</div>
			<?php
				$author_ID = get_post_field( 'post_author', $post->ID );
				 //Gets all the data of the author, using the ID
				$authorData = get_userdata( $author_ID );
				//var_dump($authorData->roles);
				if( is_user_logged_in() ) {	
				$user_details = new WP_User(get_current_user_id());
				//var_dump($user_details);
				$user_id = $user_details->ID;	
				$user_email = $user_details->user_email;
				$user_name = $user_details->display_name;
				$user_role = $user_details->roles[0];
				if($user_role == 'subscriber') { 
				//checks if the author has the role of 'subscriber'
				if (in_array( 'administrator', $authorData->roles)){
				echo "<button class='jrButton jrBlue jrclaimListing'><span class='jrIconAddListing'></span>Claim Listing</button>";
				}
				}
				}else{
				echo "<button class='jrButton jrBlue jrclaimListinglogin'><span class='jrIconAddListing'></span>Claim Listing</button>";
				}
				
				
				?>
			<div class="jrClear"></div>
		</div>
		<div class="jrAuthorInfo">
		</div>
		<div class="jrListingInfoContainer premiumListing">
			<div class="jrListingInfo">
				<div class="jrOverallRatings">
					<div class="jrOverallUser jrRatingsLarge" title="User rating">
						<?php echo do_shortcode('[comment_rating_display_rating postid="' . $post->ID . '"]')//echo do_shortcode('[comment_rating_display_rating]'); ?>									
					</div>
				</div>
				<span class="jrListingStatus">
				<span class="fwd-ml-1" title="Video count"><span class="jrIconVideo"></span>1</span>
				<span class="fwd-ml-1" title="Photo count"><span class="jrIconPhoto"></span>10</span>
				<span class="fwd-ml-1" title="Favorite count"><span class="jrIconFavorite"></span><span class="jr-favorite-23107">0</span></span>
				</span>
				<div class="jrClear">
					<div class="customNav">
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".jrListingInfoContainer" onclick="return false;">Overview</a>
						</div>
						<?php
							$amenities = get_field('amenities', $post->ID);                       
							if( $amenities ): ?>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".jrFieldGroup.amenities" onclick="return false;">Amenities</a>
						</div>
						<?php endif; ?>
						<?php
							$services = get_field('services', $post->ID);                       
							if( $services ): ?>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".jrFieldGroup.services" onclick="return false;">Services</a>
						</div>
						<?php endif; ?>
						<?php
							$languages_spoken = get_field('languages_spoken', $post->ID);                       
							if( $languages_spoken ): ?>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".jrFieldGroup.languages" onclick="return false;">Languages</a>
						</div>
						<?php endif; ?>
						<?php 
							$private_room_costmonth = get_field( 'private_room_costmonth', $post->ID );
							$shared_room_costmonth = get_field( 'shared_room_costmonth', $post->ID );
							if($private_room_costmonth || $shared_room_costmonth):
							
							?>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".jrFieldGroup.pricing" onclick="return false;">Pricing</a>
						</div>
						<?php endif; ?>
						<?php 
							$property_video = get_field( 'property_video', $post->ID );
							if($property_video):
							?>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".jr-video-gallery" onclick="return false;">Video</a>
						</div>
						<?php endif; ?>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector=".mapHeading" onclick="return false;">Map</a>
						</div>
						<div class="customNavItem">
							<a class="jumpLink" href="#" data-selector="#userReviews" onclick="return false;">Reviews</a>
						</div>
					</div>
					<div class="jrClear"></div>
				</div>
				<div class="jrListingInfoButtons">
				</div>
			</div>
			<div class="customHeader  uk-card-small uk-card-body">
				<table>
					<tbody>
						<tr id="row1">
							<td class="coverTd">
								<div class="customCover">
									<div class="customCover1" style="padding-right:10px; padding-left:10px">
									</div>
									<?php
										$images = get_field('add_propertymedia', $post->ID);
										if($images):
										?>
									<div class="jr-photo-gallery jrPhotoGallery" style="display: block;">
										<div id="jr-photo-slideshow" class="jrPhotoSlideShow jrPhotoOverlay" data-height="0.75" data-width="auto" data-image-crop="landscape" data-image-position="center" data-transition="slide" data-initial-transition="fade">
											<div class="galleria-container notouch galleria-theme-classic" style="width: 492px; height: 369px;">
												<div class="galleria-thumbnails-container">
													<div class="galleria-thumb-nav-left disabled"></div>
													<div class="galleria-thumbnails-list" style="overflow: hidden; position: relative;">
														<div class="galleria-thumbnails" style="overflow: hidden; position: relative; width: 405px; height: 40px;">
															<?php 
																//print_r($images);
																if( $images ):
																    foreach( $images as $image ): ?>
															<div class="galleria-image active" style="overflow: hidden; position: relative; visibility: visible; width: 40px; height: 40px;"><img src="<?php echo esc_url($image['url']); ?>" style="display: block; opacity: 1; min-width: 0px; min-height: 0px; max-width: none; max-height: none; transform: translate3d(0px, 0px, 0px); width: 40px; height: 40px; position: absolute; top: 0px; left: 0px;" width="40" height="40" alt="<?php echo esc_attr($image['alt']); ?>">
															</div>
															<?php endforeach;
																endif; ?>										
														</div>
													</div>
													<div class="galleria-thumb-nav-right disabled"></div>
												</div>
											</div>
										</div>
									</div>
									<?php else:?>
									<div class="jr-photo-gallery jrPhotoGallery" style="display: block;">
										<div id="jr-photo-slideshow" class="jrPhotoSlideShow jrPhotoOverlay" data-height="0.75" data-width="auto" data-image-crop="landscape" data-image-position="center" data-transition="slide" data-initial-transition="fade">
											<div class="galleria-container notouch" style="width: 616px; height: 412px;">
												<div class="galleria-stage">
													<img src="<?php echo plugins_url();?>/carehome-property/public/images/no-property.png" style="width: 616px; height: 412px;" alt="">
												</div>
											</div>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</td>
							<td class="contactTd">
								<div class="customContact" style="display: block;">
									<div class="contactLogo">
										<?php
											$src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), array( 5600,1000 ), false, '' );
											if($src):
											?>
										<figure class="jrHeaderLogo" style="background-color: #ffffff;">
											<img src="<?php echo $src[0]; ?>" alt="Vista Gardens Memory Care" title="Vista Gardens Memory Care">					
										</figure>
										<?php endif; ?>
									</div>
									<div id="contactInfo">
										<div class="jrFieldGroup contact-info" style="display: block;">
											<h3 class="jrFieldGroupTitle">Contact </h3>
											<div class="jrPhonenumber jrFieldRow">
												<div class="jrFieldLabel">Phone Number</div>
												<div class="jrFieldValue"><i class="fa fa-phone"></i> <?php 
													$contactInfo_phone_number = get_field( 'contactInfo_phone_number', $post->ID );
													if($contactInfo_phone_number):
														echo $contactInfo_phone_number;
													endif;
													?>	</div>
											</div>
											<div class="jrWebsite jrFieldRow"></div>
											<div class="jrLicense jrFieldRow"></div>
										</div>
										<div class="jrFieldGroup location">
											<h3 class="jrFieldGroupTitle">Location</h3>
											<div class="jrAddress jrFieldRow">
												<div class="jrFieldLabelDisabled"></div>
												<div class="jrFieldValuejrLabelDisabled">
													<?php 
														$pro_location_address = get_field( 'pro_location_address', $post->ID );
														if($pro_location_address):
															echo $pro_location_address;
														endif;
														?>	
												</div>
											</div>
											<div class="jrCity jrFieldRow"></div>
											<div class="jrState jrFieldRow">
												<div class="jrFieldLabel">Website</div>
												<?php 
													$contactInfo_website_url = get_field( 'contactInfo_website_url', $post->ID );
													$domain = str_ireplace('www.', '', parse_url($contactInfo_website_url, PHP_URL_HOST));
													if($contactInfo_website_url):
													?>
												<div class="jrFieldValue"><i class="fa fa-link"></i> <a href="<?php echo $contactInfo_website_url; ?>" target="_blank">
													<?php echo $domain; ?>	
													</a>
												</div>
												<?php 
													endif;
													  ?>	
											</div>
											<div class="jrPostalcode jrFieldRow"><i class="fa fa-map-marker"></i><?php 
												$pro_location_address = get_field( 'pro_location_address', $post->ID );
												if($pro_location_address):
													echo $pro_location_address;
												endif;
												$pro_location_city = get_field( 'pro_location_city', $post->ID );
												?>	
												,<br> <a href="<?php echo site_url() . '/properties/?jr_city=' . $pro_location_city; ?>"><?php 
													if($pro_location_city):
														echo $pro_location_city;
													endif;
													?></a>, <a href=""><?php 
													$pro_location_state = get_field( 'pro_location_state', $post->ID );
													if($pro_location_state):
														echo $pro_location_state;
													endif;
													?></a> <?php 
													$pro_location_zip_code = get_field( 'pro_location_zip_code', $post->ID );
													if($pro_location_zip_code):
														echo $pro_location_zip_code;
													endif;
													?>	
											</div>
										</div>
									</div>
									<div class="contactInquiry">
										<div id="jr-form-inquiry-outer">
											<form id="jr-form-inquiry" class="" name="jr-form-inquiry" action="javascript:void(0);" method="post">
												<table>
													<tbody>
														<tr>
															<td>
																<input type="text" name="jr-inquiry-from_name" id="jr-inquiry-from_name" class="jrName" placeholder="Enter your name" maxlength="100" value="">											
															</td>
															<td>
																<input type="text" name="jr-inquiry-phone" id="jr-inquiry-phone" class="jrPhone" placeholder="Enter Your phone #" maxlength="100" value="">											
															</td>
														</tr>
														<tr>
															<td colspan="2">
																<input type="email" name="r-inquiry-from_email" id="jr-inquiry-from_email" class="jrEmail" placeholder="Enter Your email" maxlength="100" value="">											
															</td>
														</tr>
														<tr>
															<td colspan="2" class="messageTd">
																<textarea name="jr-inquiry-message" id="jr-inquiry-message" class="jrTextArea" placeholder="Hi, I have a few questions, please tell me about..." rows="4"></textarea>											
															</td>
														</tr>
														<tr>
															<td colspan="2" class="validationTd">
																<label for="jr-inquiry-from_name"></label>
																<label for="jr-inquiry-from_email"></label>
																<label for="jr-inquiry-message"></label>
																<div class="formValidation"></div>
															</td>
														</tr>
													</tbody>
												</table>
												<?php
													$googlemap_capcha_api = get_option( 'googlemap_capcha_api_settings_option_name');
													$capchakey = $googlemap_capcha_api['recaptcha_site_key_0']; 
													if(isset($capchakey)){
													  $capchaApiKey = $capchakey;
													}else{
													  $capchaApiKey = '6Lf6VLAUAAAAAPqPJUEFT87XM6JWU4D3HOzyB1AA';
													}
													?>
												<div class="jr-captcha jrCaptcha">
													<script src="https://www.google.com/recaptcha/api.js" async defer></script>
													<div class="jr-captcha jrCaptcha">
														<div class="g-recaptcha" data-sitekey="<?php echo $capchaApiKey; ?>" data-callback="recaptchaCallback"></div>
														<div id="google-recaptcha-error1"></div>
													</div>
													<input type="hidden" class="hiddenRecaptcha required" name="hiddenRecaptcha1" id="hiddenRecaptcha1">
												</div>
												<div class="sendInquiryTd">
													<div class="inquiryButton">
														<div>
															<p>Send your message<img src="<?php echo plugins_url();?>/carehome-property/public/images/send.png" class="saveIcon"></p>
														</div>
													</div>
												</div>
												<button id="sendInquiry" type="submit" class="@jr-send-inquiry-embedded"></button>		
												<input type="hidden" id="authorEmail" value="<?php echo $authorData->user_email; ?>">
												<input type="hidden" id="listingName" value="<?php echo get_the_title( $post->ID ); ?>">
											</form>
										</div>
									</div>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="jrClear"></div>
	<?php
		$content = get_the_content($post->ID);
		if($content):
		?>
	<div class="jrListingFulltext  " itemprop="description">
		<h3 class="jrFieldGroupTitle" style="float: left;padding-top: 0;     margin-bottom: 30px;">Description</h3>
		<hr class="fieldTitleLine" style="width: 674px;">
		<div class="jrClear"></div>
		<div>
			<p><?php
				echo $content;
				   
				?>
			</p>
		</div>
	</div>
	<?php endif; ?>
	<div class="jrCustomFields">
		<?php
			$amenities = get_field('amenities', $post->ID);                       
			if( $amenities ): ?>
		<div class="jrFieldGroup amenities">
			<h3 class="jrFieldGroupTitle" style="float: left;">Amenities</h3>
			<hr class="fieldTitleLine" style="width: 691px;">
			<div class="jrClear"></div>
			<div class="jrAmenities jrFieldRow">
				<div class="jrFieldLabelDisabled"></div>
				<div class="jrFieldValuejrLabelDisabled">
					<ul class="jrFieldValueList">
						<li>Activity Center</li>
						<?php foreach( $amenities as $amenitie ): ?>
						<li><?php echo $amenitie; ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php
			$services = get_field('services', $post->ID);                          
			
			if( $services ): ?>
		<div class="jrFieldGroup services">
			<h3 class="jrFieldGroupTitle" style="float: left;">Services</h3>
			<hr class="fieldTitleLine" style="width: 705px;">
			<div class="jrClear"></div>
			<div class="jrServices jrFieldRow">
				<div class="jrFieldLabelDisabled"></div>
				<div class="jrFieldValuejrLabelDisabled">
					<ul class="jrFieldValueList">
						<?php foreach( $services as $service ): ?>
						<li><?php echo $service; ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
		<?php endif; ?>	
		<?php
			$languages = get_field('languages_spoken', $post->ID);                        
			
			if( $languages ): ?>	
		<div class="jrFieldGroup languages">
			<h3 class="jrFieldGroupTitle" style="float: left;">Languages</h3>
			<hr class="fieldTitleLine" style="width: 685px;">
			<div class="jrClear"></div>
			<div class="jrLanguagesspoken jrFieldRow">
				<div class="jrFieldLabelDisabled"></div>
				<div class="jrFieldValuejrLabelDisabled">
					<ul class="jrFieldValueList">
						<?php foreach( $languages as $language ): ?>
						<li><?php echo $language; ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
		<?php endif; ?>	
		<?php 
			$private_room_costmonth = get_field( 'private_room_costmonth', $post->ID );
			$shared_room_costmonth = get_field( 'shared_room_costmonth', $post->ID );
			if($private_room_costmonth || $shared_room_costmonth):
			
			?>
		<div class="jrFieldGroup pricing" style="">
			<h3 class="jrFieldGroupTitle" style="float: left;">Pricing</h3>
			<hr class="fieldTitleLine" style="width: 0px;">
			<div class="jrClear"></div>
			<div class="jrPrivateroomcostmonth jrFieldRow">
				<?php 
					if($private_room_costmonth):
					?>
				<div class="jrFieldLabel">Private Room Cost/Month</div>
				<div class="jrFieldValue"><?php echo $private_room_costmonth; ?></div>
				<?php endif; ?>
			</div>
			<div class="jrSharedroomcostmonth jrFieldRow">
				<?php 
					if($shared_room_costmonth):
					?>
				<div class="jrFieldLabel">Shared Room Cost/Month</div>
				<div class="jrFieldValue"><?php echo $shared_room_costmonth; ?></div>
				<?php endif; ?>
			</div>
		</div>
		<?php endif; ?>
		<?php 
			$property_video = get_field( 'property_video', $post->ID );
			if($property_video):
			?>
		<div class="jrFieldGroup jr-video-gallery">
			<h3 class="jrFieldGroupTitle" style="float: left;">Video</h3>
			<hr class="fieldTitleLine" style="width: 685px;">
			<div class="jrClear"></div>
			<div class="jrVideo">
				<div class="video-player-outer">
					<div id="jr-video-embed-player" class="jr-video-embed-player jrHidden" data-embed="youtube" style="display: block;">
						<div class="fluid-width-video-wrapper">
							<?php echo $property_video; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<div class="jrFieldGroup mapHeading">
			<h3 class="jrFieldGroupTitle" style="float: left;">Map</h3>
			<hr class="fieldTitleLine" style="width: 685px;">
			<div class="jrClear"></div>
			<div class="mapouter">
				<div class="gmap_canvas"><iframe width="971" height="400" id="gmap_canvas" src="https://maps.google.com/maps?q='<?php if($pro_location_address): echo $pro_location_address; endif;?>'&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.embedgooglemap.net/blog/nordvpn-coupon-code/"></a></div>
				<style>.mapouter{position:relative;text-align:right;height:300px;width:100%;}.gmap_canvas {overflow:hidden;background:none!important;height:300px;width:100%;}</style>
			</div>
		</div>
	</div>
	<div class="jrClear"></div>
</div>
<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('.comment-respond').hide();
	    $('#Leave_a_comment').click(function() {
	        $('.comment-respond').toggle();
	    })
	    $('.jrclaimListinglogin').click(function() {
	        $('#loginmodal').modal({
	            backdrop: 'static',
	            keyboard: false
	        });
	    })
	    $('.jrclaimListing').click(function() {
	        $('#jrclaimListing').modal({
	            backdrop: 'static',
	            keyboard: false
	        });
	    })
	});
</script>
<?php
	echo '<script type="text/javascript">
	          var ajaxurl = "' . admin_url('admin-ajax.php') . '";
	          var s2AjaxUri = "/wp-admin/admin-ajax.php?action=jreviews_ajax";
	        </script>';
	
	?>
<div id="loginmodal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close hidelogopenreg" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="modal-title" id="modalLabel">Sign in to your account</h3>
			</div>
			<div class="modal-body">
				<form id="user-account-log-in" class="user-account-login jrForm" action="javascript:void(0);" method="post">
					<div id="log-success"></div>
					<div id="log-error"></div>
					<input type="hidden" name="ajaxUrl_action" id="pro_ajaxUrl_action" value="<?php echo admin_url('admin-ajax.php'); ?>">
					<input type="hidden" name="prop_redirect_to" id="prop_redirect_to" value="<?php echo get_the_permalink($post->ID); ?>">
					<input type="hidden" name="action" id="logaction" value="PropertyLoginProcess" />
					<div class="jrFieldDiv"> 
						<input class="form-control jrText" placeholder="E-mail address" type="email" name="prop_wpmp_email1" id="prop_wpmp_email1" width="100%">
					</div>
					<div class="jrFieldDiv"> 
						<input class="form-control jrName" placeholder="Password" type="password" name="prop_wpmp_password1" id="prop_wpmp_password1">
					</div>
					<div class="jrFieldDiv"> 
						<button type="submit" class="jrButton jrLarge jrBlue">Sign in</button>
					</div>
					<div class="jrFieldDiv"> <a href="<?php echo site_url() . '/wp-login.php?action=lostpassword'; ?>">Forgot your password?</a></div>
				</form>
			</div>
			<div class="modal-footer">
				<div class="options text-right">
					<p class="pt-1">Don't have an account? <a href="<?php echo site_url().'/property-sign-up/'?>" class="blue-text">Sign Up</a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="jrclaimListing" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close hidelogopenreg" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h3 class="modal-title" id="modalLabel">Claim Listing Form</h3>
			</div>
			<div class="modal-body">
				<div id="pro-success"></div>
				<div id="pro-error"></div>
				<form id="listing_submit_form" action="javascript:void(0);">
					<input type="hidden" class="form-control" name="listing_user_id" id="listing_user_id" value="<?php echo $user_id; ?>">
					<input type="hidden" class="form-control" name="listing_post_id" id="listing_post_id" value="<?php echo $post->ID; ?>">
					<input type="hidden" name="listing_ajaxUrl_action" id="listing_ajaxUrl_action" value="<?php echo admin_url('admin-ajax.php'); ?>">
					<input type="hidden" name="listingaction" id="listingaction" value="ClaimListingProcess" />
					<div class="form-group">
						<label for="pwd">Name:</label>
						<input type="text" class="form-control" name="listing_name" id="listing_name" value="<?php echo $user_name; ?>" required>
					</div>
					<div class="form-group">
						<label for="email">Email address:</label>
						<input type="email" class="form-control" name="listing_email" id="listing_email" value="<?php echo $user_email; ?>" required>
					</div>
					<div class="form-group">
						<label for="pwd">Message:</label>
						<textarea name="listing_message" class="form-control" id="listing_message" required></textarea>
					</div>
					<button type="submit" class="jrButton jrLarge jrGreen listing_submit">Submit</button>
				</form>
			</div>
			<div class="modal-footer">
				<div class="options text-right">
				</div>
			</div>
		</div>
	</div>
</div>