<?php
  /**
  * Provide a user-facing view for the plugin
  *
  * This file is used to markup the user-facing aspects of the plugin.
  *
  * @link       http://example.com
  * @since      1.0.0
  *
  * @package    Carehome_Property
   @subpackage Carehome_Property/public/partials
  */ 
  ?>

  <?php


  ?>


<div class="jr-page jrPage">
  <div class="jrPageHeader"></div>
  <div class="jrMapviewPage">
    <div class="jr-map">
      <div class="jr-map-header jrMapHeader">
        <div class="jr-map-search jrMapAddressBar">
          <div class="jrLocationSearch jrForm">
            <div class="jrAddressGeolocation">
              <input id="input-location" type="text" size="50" class="jr-location jrLocation ui-autocomplete-input" name="location" placeholder="Enter a location" autocomplete="off" />
            </div>
            <!-- <button class="jr-map-search-btn jrButton jrBlue jrIconOnly">
              <span class="jrIconSearch"></span>
            </button> -->
          </div>
          <a class="jr-map-show-filters jrBtnShowFilters jrButton jrDark">
            <span class="jrIconMap"></span>
            <span>Refresh</span>
          </a>
          <div class="jr-map-sidebar-header jrMapSidebarHeader" style="">
            <div class="jrMapResultsTotal"> 
              <span class="jrMapResultsOrder fwd-ml-2">
                Ordered by 
                <select name="order" class="jr-map-order jrSelect">
                  <option value="all" selected="selected">All</option>
                  <option value="featured">Featured</option>
                  <option value="title">Title</option>
                  <option value="rdate">Most recent</option>
                  <option value="reviews">Most reviews</option>
                  <!-- <option value="rhits">Most popular</option>
                  <option value="rating">User rating</option>
                  <option value="editor_rating">Editor rating</option> -->
                </select>
              </span>
              <span class="map-list">
                <div class="paginate">
                  <a class="next-count" href="#">&raquo;</a>
                  <a class="current-count" href="#">1</a>
                  <a class="previous-count isDisabled" href="#">&laquo;</a>
                  
                </div>
                <div class="c-pagination-info">
                  Showing 
                  <span class="jr-map-results-current">1 to 250</span> 
                  of 
                  <span class="jr-map-results-total">10908</span> 
                  results. 
                </div>
              </span>
            </div>
            <div class="jrMapResultsDesc"> 
              
            </div>
          </div>
        </div>
      </div>
      <div class="jrMapWidget jrClearfix">
        <div class="jrMapWidgetLeft">
          <div id="map" class="jr-map-canvas-col jrMapCanvasCol" style="margin-right: 450px; height: 400px; width: 590px;">
            <!-- <div class="jr-map-loading-bar jrMapLoadingBarOuter jrHidden">
              <div class="jrMapLoadingText">Adding markers to the map ...</div>
              <div class="jrMapLoadingBar">
                <div class="jr-map-loading" style="width: 0px;"></div>
              </div>
            </div> -->
            
            <!-- <div class="jr-map-listing-slideout-wrapper jrMapListingSlideoutWrapper" style="display:none;"> -->
              <!-- <div class="jr-map-listing-slideout jrMapListingSlideout" style=""></div> -->
            <!-- </div> -->
          </div>
        </div>
        <div class="jr-map-sidebar-col jrMapSidebarCol" style="width: 440px; margin-left: -440px; height: 400px;">
          <div class="jr-map-listings jrMapListingSidebar" style="height:400px;">
            
          </div>
        </div>
      </div>
      <?php
      echo '<script type="text/javascript">
              var ajaxurl = "' . admin_url('admin-ajax.php') . '";
            </script>';

      ?>
      <script type="text/javascript">
        var map, infoWindow, autocomplete;
        // cen = {lat: 34.0783584, lng: -107.6183633}
        function initMap(cen) {
          map = new google.maps.Map(document.getElementById('map'), {
            center: cen,
            zoom: 8
          });
          infoWindow = new google.maps.InfoWindow;
          autocomplete = new google.maps.places.Autocomplete(document.getElementById('input-location'), {types: ['geocode']});
        }

        jQuery(document).ready(function($){
          var locations = [{lat: 0, lng: 0}];
          var input = '';
          var order = '';
          var address = '';
          var first = 0;
          var feature = '';
          var loc = '';
          

          // Create an array of alphabetical characters used to label the markers.
          var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

          var title = [];
          var content = [];

          $('.jr-map-order').change(function(){
            order = $(this).val();
            if($('#input-location').attr('lat')){
              loc = {
                lat: Number($('#input-location').attr('lat')), 
                lng: Number($('#input-location').attr('lng'))
              };
              initMap(loc);
            }
            $('.jr-map-listings').html('');
            getData(order,loc, 1);
          });

          if(first < 1){
            first = 1;
            getData();
          }

          $('.next-count').click(function(){
            if($(this).hasClass('isDisabled')){
              return false;
            }

            step = parseInt($('.current-count').html());
            step = step + 1;
            order = $('.jr-map-order').val();
            initMap(loc);
            $('.jr-map-listings').html('');
            getData(order,loc, step);
          });

          $('.previous-count').click(function(){
            if($(this).hasClass('isDisabled')){
              return false;
            }

            step = parseInt($('.current-count').html());
            step = step - 1;
            order = $('.jr-map-order').val();
            initMap(loc);
            $('.jr-map-listings').html('');
            getData(order,loc, step);
          });

          $('#input-location').change(function(){
            feature = $('.jr-map-order').val();
            $("#map").html('');
            if (navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(function(position) {
                var geolocation = {
                  lat: position.coords.latitude,
                  lng: position.coords.longitude
                };
                var circle = new google.maps.Circle(
                    {center: geolocation, radius: position.coords.accuracy});
                autocomplete.setBounds(circle.getBounds());
              });

              autocomplete.bindTo('bounds', map);

              autocomplete.setFields(['address_components', 'geometry', 'icon', 'name']);

              autocomplete.addListener('place_changed', function() {
                infoWindow.close();
                // marker.setVisible(false);

                var place = autocomplete.getPlace();
                
                if (!place.geometry) {
                  // User entered the name of a Place that was not suggested and
                  // pressed the Enter key, or the Place Details request failed.
                  window.alert("No details available for input: '" + place.name + "'");
                  return;
                }
                
                // If the place has a geometry, then present it on a map.
                if (place.geometry.viewport) {
                  map.fitBounds(place.geometry.viewport);
                } else {
                  map.setCenter(place.geometry.location);
                  map.setZoom(8);
                }

                var address = '';
                if (place.address_components) {
                  address = [
                    (place.address_components[0] && place.address_components[0].short_name || ''),
                    (place.address_components[1] && place.address_components[1].short_name || ''),
                    (place.address_components[2] && place.address_components[2].short_name || '')
                  ].join(' ');
                }

                loc = {
                        lat: place.geometry.location.lat(),
                        lng: place.geometry.location.lng()
                      };
                $('#input-location').attr('lat', place.geometry.location.lat());
                $('#input-location').attr('lng', place.geometry.location.lng());
                initMap(loc);
                $('.jr-map-listings').html('');
                getData(feature, loc, 1);
              });
            }
          });

          function getData(feature, loc, step){
            $.ajax({
                url: ajaxurl,
                type : "GET",
                data : {
                  'action' : 'property_map_search_Ajax',
                  'feature': feature, 
                  'location': loc,
                  'step': step
                },
                success: function(data){
                  var tot = 0;
                  $('.next-count').removeClass('isDisabled');
                  $('.previous-count').removeClass('isDisabled');
                    data = JSON.parse(data);
                    locations = [];
                    $(data.location).each(function(i, item){
                      var prop = '<div id="jr-map-listing-'+item.ID+'" class="jrMapListing">\
                      <div class="jrListingPhotoContent" style="width: 210px; height: 161.7px;">\
                      <div class="jrListingPhotoWrapper" style="background-image: url('+item.image+'); height: 161.7px;">\
                      <div class="jr-listing-thumbnail jrListingPhoto" data-id="'+item.ID+'">\
                      <div class="jrOverallRatings">\
                      <div class="jrOverallUser" title="" user="" rating="2"> \ ' +item.rating + '                      </div>\
                      </div>\
                      <div class="jrListingActionsWrapper">\
                      </div>\
                      </div>\
                      </div>\
                      </div>\
                      <div class="jrListingContent" style="width: 190px;">\
                      <div class="jrMapListingTitle"> \
                      <a href="<?php echo site_url() . '/properties/';?>'+item.post_name+'">'+item.post_title+'</a>';
                      
                      if(item.featured == 'yes'){
                        prop = prop + '<span class="jrStatusIndicators">\
                      <span class="jrStatusLabel jrBlue">Featured</span>\
                      </span>';
                      }

                      prop = prop + '</div>\
                      <div class="jrMapListingAuthor"></div>\
                      <div class="jrMapListingCategory">\
                      <span>Category:</span><a href="<?php echo site_url() . '/properties/?jv_category=';?>'+item.category_url+'">'+item.category_name+'</a>\
                      </div>\
                      <div class="jrCustomFields">\
                      <div class="jrFieldGroup">\
                      <div class="jrFieldRow">\
                      <div class="jrFieldValue">\
                      <a href="<?php echo site_url() . '/properties/?jr_city[]=';?>'+item.city+'">'+item.city+'</a>\
                      </div>\
                      </div>\
                      </div>\
                      </div>\
                      </div>\
                      </div>';

var prop1 = 
  '<div class="jrInfowindow" style="font-size: 10px;white-space: normal;word-wrap: break-word; background: #fff;text-align: left;">\
    <div class="jrMapListing" style="color: #fff;text-decoration: none!important;">\
        <div class="jrListingPhotoContent">';
               var prop1 = prop1 + '<div class="jrListingPhotoWrapper" style="background-image: url('+item.image+'); height: 119.7px;">\
            <div class="jr-listing-thumbnail jrListingPhoto" data-id="'+item.ID+'">';
            
              var prop1 = prop1 + '<div class="jrOverallRatings">\
                <div class="jrOverallUser" title="" user="" rating="2">\
                <span class="jrIconUsers jrRatingLabel"></span>\
                ' +item.rating + 
                '</div>\
              </div>\
              <div class="jrListingContent" style="width: 190px;">\
                <div class="jrMapListingTitle"> \
                <a href="<?php echo site_url() . '/properties/';?>'+item.post_name+'">'+item.post_title+'</a>\
                </div>\
                 <div class="jrMapListingAuthor"></div>\
                   <div class="jrCustomFields">\
                     <div class="jrFieldGroup">\
                     <div class="jrFieldRow">\
                     <div class="jrFieldValue">\
                     <a href="<?php echo site_url() . '/properties/?jr_city[]=';?>'+item.city+'">'+item.city+'</a>\
                     </div>\
                     </div>\
                   </div>\
                 </div>\
              </div>\
            </div>\
          </div>\
        </div>\
    </div>\
  </div>';

                      $('.jr-map-listings').append(prop);

                      tot = i+1;
                      
                      if(item.lat != '' && item.lng != ''){
                        locations[i] = {lat: Number(item.lat), lng: Number(item.lng)};
                        title[i] = item.title;
                        content[i] = prop1;
                      }
                    });

                    var count = '';
                    if(step > 1){
                      var num = 250 * step;
                      console.log(num);
                      var frm = (250 * (step - 1)) + 1;
                      console.log(frm);
                      if(num == data.totcount){
                        $('.next-count').addClass('isDisabled');
                      }
                      console.log(step);
                      if(tot < num || num == data.totcount){
                        num = frm + tot - 1;
                      }
                      console.log(tot);
                      count = frm + ' to ' + num;
                      $('.current-count').html(step);
                    }else{
                      count = '1 to '+ tot;
                      $('.previous-count').addClass('isDisabled');
                      if(tot == data.totcount){
                        $('.next-count').addClass('isDisabled');
                      }
                      $('.current-count').html(1);
                    }
                    $('.jr-map-results-current').html(count);

                    $('.jr-map-results-total').html(data.totcount);

                    if(!loc){
                      var cen = averageGeolocation(locations);
                      initMap(cen);
                    }
                    callMap();
                },
                error : function(data){
                  
                }
            });
          }

          function callMap(){
            var markers = [];
            $(locations).each(function(i, location) {
             // console.log(title[i]);
              var marker = new google.maps.Marker({
                position: location,
                map: map,
                title: title[i]
              });

              var infowindow = new google.maps.InfoWindow({
                title: title[i]
              });

              marker.addListener('zoom_changed', function() {
                infowindow.setContent('Zoom: ' + map.getZoom());
              });

              marker.addListener('click', function() {
                        //close all
        /*        for (var i = 0; i < infowindow.length; i++) {
                  infowindow[i].close();
                }*/

                infowindow.setContent(content[i]);
                infowindow.open(map, marker);
                currentMark = this;
              });
              markers.push(marker);
              google.maps.event.addListener(map, 'click', function() {
                infowindow.close();
              });


            });


            var markerCluster = new MarkerClusterer(map, markers,
              {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
          }


          $('.jr-map-show-filters').click(function(){
            $('#input-location').val('');
            $('#input-location').removeAttr('lat');
            $('#input-location').removeAttr('lng');
            $('.jr-map-order').find('option').removeAttr('selected');
            $('.jr-map-order').find('option:first').attr('selected', 'selected');
            $('.jr-map-listings').html('');
            getData();
          });


          function averageGeolocation(coords) {
            if (coords.length === 1) {
              return coords[0];
            }

            let x = 0.0;
            let y = 0.0;
            let z = 0.0;

            for (let coord of coords) {
              let latitude = coord.lat * Math.PI / 180;
              let longitude = coord.lng * Math.PI / 180;

              x += Math.cos(latitude) * Math.cos(longitude);
              y += Math.cos(latitude) * Math.sin(longitude);
              z += Math.sin(latitude);
            }

            let total = coords.length;

            x = x / total;
            y = y / total;
            z = z / total;

            let centralLongitude = Math.atan2(y, x);
            let centralSquareRoot = Math.sqrt(x * x + y * y);
            let centralLatitude = Math.atan2(z, centralSquareRoot);

            return {
              lat: centralLatitude * 180 / Math.PI,
              lng: centralLongitude * 180 / Math.PI
            };
          }
          
        });

      </script>
      <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js">
    </script>
      <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDLGBc-OgMg7P2h7f-HBUJaG6wY1KIubuQ&libraries=places&callback=initMap">
    </script>
    </div>
  </div>
</div>

<style type="text/css">
  span.map-list {
    display: inline-block;
    margin-right: .75em;
    line-height: normal;
  }

  .paginate a {
    color: black;
    float: right;
    padding: 10px 15px 10px;
    text-decoration: none;
    border: 1px solid #ddd;
  }

  .paginate a.active {
    background-color: #4CAF50;
    color: white;
    border: 1px solid #4CAF50;
  }

  .paginate a:hover:not(.active) {background-color: #ddd;}

  .paginate a:first-child {
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
  }

  .paginate a:last-child {
    
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
  }

  .isDisabled {
    color: currentColor;
    cursor: not-allowed;
    opacity: 0.5;
    text-decoration: none;
  }
  .jrMapResultsOrder {
    padding-bottom: 33px;
    margin-right: 28px;
  }
  .jrMapResultsOrder,
  span.map-list {
    display: inline-block;
    vertical-align: middle;
    
  }
  .paginate {
    overflow: hidden;
  }
  .c-pagination-info {
    margin-bottom: 10px ;
    margin-top: 5px;
  }
</style>