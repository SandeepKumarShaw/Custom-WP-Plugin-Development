<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Carehome_Property
 * @subpackage Carehome_Property/public
 */
class Comment_Rating {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}
	public function property_ajax_comments_scripts() {
		//global $post;
		 if ( get_post_type() == 'property' ){
		 	 if ( is_single() ) {
			 
				// I think jQuery is already included in your theme, check it yourself
				//wp_enqueue_script('jquery');
			 
				// just register for now, we will enqueue it below
				wp_register_script( 'ajax_comment', plugin_dir_url( __FILE__ ) . 'js/ajax-comment.js', array('jquery') );
			 
				// let's pass ajaxurl here, you can do it directly in JavaScript but sometimes it can cause problems, so better is PHP
				wp_localize_script( 'ajax_comment', 'property_ajax_comment_params', array(
					'ajaxurl' => site_url() . '/wp-admin/admin-ajax.php'
				) );
			 
			 	wp_enqueue_script( 'ajax_comment' );
			 }
		 }
	}
	public function property_comment_rating_styles() {
		//global $post;
		 if ( get_post_type() == 'property' || is_page('property-map-search')){
		 	 if ( is_single() || get_post_type() == 'property' || is_page('property-map-search')) {

			//wp_enqueue_style( $this->plugin_name . '-theme', plugin_dir_url( __FILE__ ) . 'css/theme_css/theme.min.css', array(), $this->version, 'all' );


			wp_register_style( 'ci-comment-rating-styles', plugin_dir_url( __FILE__ ) . 'css/ratingstyle.css' );

			wp_enqueue_style( 'dashicons' );
			wp_enqueue_style( 'ci-comment-rating-styles' );
		   }
		}
	}	
	public function property_comment_rating_rating_field () {
	?>
		<label for="rating">Rating<span class="required">*</span></label>
		<fieldset class="comments-rating">
			<span class="rating-container">
				<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
					<input type="radio" id="rating-<?php echo esc_attr( $i ); ?>" name="rating" value="<?php echo esc_attr( $i ); ?>" class="rating" /><label for="rating-<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i ); ?></label>
				<?php endfor; ?>
				<input type="radio" id="rating-0" class="star-cb-clear" name="rating" value="0" /><label for="rating-0">0</label>
			</span>
		</fieldset>
		<?php
	}
	public function property_comment_rating_save_comment_rating( $comment_id ) {
		if ( ( isset( $_POST['rating'] ) ) && ( '' !== $_POST['rating'] ) )
		$rating = intval( $_POST['rating'] );
		add_comment_meta( $comment_id, 'rating', $rating );
	}
	public function property_comment_rating_require_rating( $commentdata ) {
		if ( ! is_admin() && ( ! isset( $_POST['rating'] ) || 0 === intval( $_POST['rating'] ) ) )
		wp_die( __( 'Error: You did not add a rating. Hit the Back button on your Web browser and resubmit your comment with a rating.' ) );
		return $commentdata;
	}
	public function property_comment_rating_display_rating( $comment_text ){

		if ( $rating = get_comment_meta( get_comment_ID(), 'rating', true ) ) {
			$stars = '<p class="stars">';
			for ( $i = 1; $i <= $rating; $i++ ) {
				$stars .= '<span class="dashicons dashicons-star-filled"></span>';
			}
			$stars .= '</p>';
			$comment_text = $comment_text . $stars;
			return $comment_text;
		} else {
			return $comment_text;
		}
	}
	public function property_comment_rating_get_average_ratings( $id ) {
		$comments = get_approved_comments( $id );

		if ( $comments ) {
			$i = 0;
			$total = 0;
			foreach( $comments as $comment ){
				$rate = get_comment_meta( $comment->comment_ID, 'rating', true );
				if( isset( $rate ) && '' !== $rate ) {
					$i++;
					$total += $rate;
				}
			}

			if ( 0 === $i ) {
				return false;
			} else {
				return round( $total / $i, 1 );
			}
		} else {
			return false;
		}
	}
	public function property_comment_rating_get_total_ratings( $id ) {
		$comments = get_approved_comments( $id );

		if ( $comments ) {
			$total = count($comments);
         return $total;
		} else {
			return false;
		}
	}
	public function property_comment_rating_display_average_rating($atts) {

		global $post;
		
		$stars   = '';
		$average = $this->property_comment_rating_get_average_ratings( $atts['postid'] );

		$total = $this->property_comment_rating_get_total_ratings( $atts['postid'] );

		for ( $i = 1; $i <= $average + 1; $i++ ) {
			
			$width = intval( $i - $average > 0 ? 20 - ( ( $i - $average ) * 20 ) : 20 );

			if ( 0 === $width ) {
				continue;
			}

			$stars .= '<span style="overflow:hidden; width:' . $width . 'px" class="dashicons dashicons-star-filled"></span>';

			if ( $i - $average > 0 ) {
				$stars .= '<span style="overflow:hidden; position:relative; left:-' . $width .'px;" class="dashicons dashicons-star-empty"></span>';
			}
		}
		if($total > 0 ){
			$custom_content = '<div class="jrRatingStars">' . $stars .'	</div>
						<span class="jrRatingValue"><span>' . $average .'</span><span class="jrReviewCount"> (<span class="count">' . $total .'</span>)</span></span>';
		}else{
			$custom_content = '';
		}

		
		return $custom_content;
	}
	public function property_comment_remove_comment_url($arg) {
		global $post;
		if ( 'property' == $post->post_type ){
		 	 if ( is_single() ) {
		       $arg['url'] = '';
		       return $arg;
			}
		}
	}
/*	public function property_comment_form_logged_in( $logged_in_as, $commenter, $user_identity ) {

		$logged_in_as .= '<p>' . __( 'We appreciated comments from registered users and are happy to read your feedback.' ) . '</p>';

		return $logged_in_as;
	}*/
	
	public function property_comments_open( $open, $post_id ) {
	  $post = get_post( $post_id );
	  if ( 'property' == $post->post_type )
	      $open = true;
	  return $open;
	}
	public function property_submit_ajax_comment(){
		/*
		 * Wow, this cool function appeared in WordPress 4.4.0, before that my code was muuuuch mooore longer
		 *
		 * @since 4.4.0
		 */
		$comment = wp_handle_comment_submission( wp_unslash( $_POST ) );
		if ( is_wp_error( $comment ) ) {
			$error_data = intval( $comment->get_error_data() );
			if ( ! empty( $error_data ) ) {
				wp_die( '<p>' . $comment->get_error_message() . '</p>', __( 'Comment Submission Failure' ), array( 'response' => $error_data, 'back_link' => true ) );
			} else {
				wp_die( 'Unknown error' );
			}
		}
	 
		/*
		 * Set Cookies
		 */
		$user = wp_get_current_user();
		do_action('set_comment_cookies', $comment, $user);
	 
		/*
		 * If you do not like this loop, pass the comment depth from JavaScript code
		 */
		$comment_depth = 1;
		$comment_parent = $comment->comment_parent;
		while( $comment_parent ){
			$comment_depth++;
			$parent_comment = get_comment( $comment_parent );
			$comment_parent = $parent_comment->comment_parent;
		}
	 
	 	/*
	 	 * Set the globals, so our comment functions below will work correctly
	 	 */
		$GLOBALS['comment'] = $comment;
		$GLOBALS['comment_depth'] = $comment_depth;
	 
		/*
		 * Here is the comment template, you can configure it for your website
		 * or you can try to find a ready function in your theme files
		 */
		$comment_html = '<li ' . comment_class('', null, null, false ) . ' id="comment-' . get_comment_ID() . '">
			<article class="comment-body" id="div-comment-' . get_comment_ID() . '">
				<footer class="comment-meta">
					<div class="comment-author vcard">
						' . get_avatar( $comment, 100 ) . '
						<b class="fn">' . get_comment_author_link() . '</b> <span class="says">says:</span>
					</div>
					<div class="comment-metadata">
						<a href="' . esc_url( get_comment_link( $comment->comment_ID ) ) . '">' . sprintf('%1$s at %2$s', get_comment_date(),  get_comment_time() ) . '</a>';
	 
						if( $edit_link = get_edit_comment_link() )
							$comment_html .= '<span class="edit-link"><a class="comment-edit-link" href="' . $edit_link . '">Edit</a></span>';
	 
					$comment_html .= '</div>';
					if ( $comment->comment_approved == '0' )
						$comment_html .= '<p class="comment-awaiting-moderation">Your comment is awaiting moderation.</p>';
	 
				$comment_html .= '</footer>
				<div class="comment-content">' . apply_filters( 'comment_text', get_comment_text( $comment ), $comment ) . '</div>
			</article>
		</li>';
		echo $comment_html;
	 
		die();
	 
	}
		// Add a note above the comment form
	public function property_comment_top_button() {
		global $post;
		if ( 'property' == $post->post_type ){
		 	 if ( is_single() ) {
				echo '<div class="jrClear"></div>';
				echo '<button class="jr-review-add jrButton jrBlue" id="Leave_a_comment" style="display: inline-block;"><span class="jrIconAddReview"></span> Add new review </button>';
			    echo '<div class="jrClear"></div>';
			}
		}
	}
	public function restrict_users($open, $post_id) {
		global $post;
		if ( 'property' == $post->post_type ){
		 	if ( is_single() || 'property' == $post->post_type) {

			   if (intval($post_id) && get_post($post_id)) {
			       $args = array('post_id' => $post_id, 'count' => true);
			       $user = wp_get_current_user();
			       if ($user && intval($user->ID)) { // for registered users
			           $skip = false;	          
			           if (!$skip) {
			               $args['user_id'] = $user->ID;
			               $open = get_comments($args) ? false : true;
			            }
			        }
			    }
			   return $open;

            }
        }
	}
}