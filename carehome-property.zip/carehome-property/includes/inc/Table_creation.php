<?php
global $wpdb; 
  $db_table_name = $wpdb->prefix . 'claim_details';  // table name
  $charset_collate = $wpdb->get_charset_collate();

if($wpdb->get_var("SHOW TABLES LIKE '$db_table_name'") != $db_table_name) {
       $sql = "CREATE TABLE $db_table_name (
                id int(11) NOT NULL auto_increment,
                user_id int(11) NOT NULL,
                property_id int(11) NOT NULL,
                name varchar(60) NOT NULL,
                emailid varchar(200) NOT NULL,
                status int(11) NOT NULL DEFAULT '0',
                message longtext NOT NULL,
                UNIQUE KEY id (id)
        ) $charset_collate;";

   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql );
}

$corn_property_mapping = $wpdb->prefix . 'corn_property_mapping';  // table name
$corn_charset_collate = $wpdb->get_charset_collate();

if($wpdb->get_var("SHOW TABLES LIKE '$corn_property_mapping'") != $corn_property_mapping) {
       $sql = "CREATE TABLE $corn_property_mapping (
                `ID` bigint(20) NOT NULL auto_increment,
                `listing_id` bigint(20) NOT NULL,
                `post_author` bigint(20) NOT NULL,
                `post_date` datetime NOT NULL,
                `post_content` longtext NOT NULL,
                `post_title` text NOT NULL,
                `post_status` varchar(20) NOT NULL,
                `post_type` varchar(20) NOT NULL,
                `featured` varchar(10) NOT NULL DEFAULT 'no',
                `jr_state` varchar(255) NOT NULL,
                `jr_city` varchar(255) NOT NULL,
                `jr_address` varchar(255) NOT NULL,
                `jr_postalcode` varchar(255) NOT NULL,
                `jr_phonenumber` varchar(255) NOT NULL,
                `jr_website` varchar(255) NOT NULL,
                `jr_license` varchar(255) NOT NULL,
                `jr_amenities` longtext NOT NULL,
                `jr_availablebedsinprivaterooms` varchar(255) NOT NULL,
                `jr_availablebedsinsharedrooms` varchar(255) NOT NULL,
                `jr_languagesspoken` longtext NOT NULL,
                `jr_services` longtext NOT NULL,
                `jr_privateroomcostmonth` varchar(255) NOT NULL,
                `jr_sharedroomcostmonth` varchar(255) NOT NULL,
                `jr_latitude` varchar(255) NOT NULL,
                `jr_longitude` varchar(255) NOT NULL,
                `filename` varchar(500) NOT NULL,
                `file_extension` varchar(255) NOT NULL,
                `rel_path` varchar(500) NOT NULL,
                `media_type` varchar(255) NOT NULL,
                `new_rel_path` varchar(500) NOT NULL,
                `post_name` varchar(255) NOT NULL,
                `term_id` varchar(255) NOT NULL,
                `term_name` varchar(255) NOT NULL,
                UNIQUE KEY id (ID)
        ) $corn_charset_collate;";

   require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   dbDelta( $sql );
}






?>