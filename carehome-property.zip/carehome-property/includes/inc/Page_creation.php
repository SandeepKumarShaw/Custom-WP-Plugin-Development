<?php

   /*C R E A T E  A Package Selection P A G E*/
    global $wpdb;

    $advanced_search_title = 'Property Advanced Search';
    $advanced_search_name = 'property-advanced-search';

    // the menu entry...
    delete_option("advanced_search_page_title");
    add_option("advanced_search_page_title", $advanced_search_title, '', 'yes');
    // the slug...
    delete_option("advanced_search_page_name");
    add_option("advanced_search_page_name", $advanced_search_name, '', 'yes');
    // the id...
    delete_option("advanced_search_page_id");
    add_option("advanced_search_page_id", '0', '', 'yes');

    $advanced_search = get_page_by_title( $advanced_search_title );
    if ( ! $advanced_search ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $advanced_search_title;
        $_p['post_content'] = "[WP_Property_Advanced_Search_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $advanced_search_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $advanced_search_id = $advanced_search->ID;

        //make sure the page is not trashed...
        $advanced_search->post_status = 'publish';
        $advanced_search_id = wp_update_post( $advanced_search );

    }
    delete_option( 'advanced_search_page_id' );
    add_option( 'advanced_search_page_id', $advanced_search_id );
/*  E N D  */



   /* C R E A T E  A Welcome Dashboard P A G E */
   // global $wpdb;

    $welcome_dashboard_title = 'Welcome Dashboard User';
    $welcome_dashboard = 'welcome-dashboard-user';

    // the menu entry...
    delete_option("welcome_dashboard_page_title");
    add_option("welcome_dashboard_page_title", $welcome_dashboard_title, '', 'yes');
    // the slug...
    delete_option("welcome_dashboard_page_name");
    add_option("welcome_dashboard_page_name", $welcome_dashboard, '', 'yes');
    // the id...
    delete_option("welcome_dashboard_page_id");
    add_option("welcome_dashboard_page_id", '0', '', 'yes');

    $the_welcome_dashboard_page = get_page_by_title( $welcome_dashboard_title );
    if ( ! $the_welcome_dashboard_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $welcome_dashboard_title;
        $_p['post_content'] = "[wp_welcome_dashboard_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_welcome_dashboard_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_welcome_dashboard_page_id = $the_welcome_dashboard_page->ID;

        //make sure the page is not trashed...
        $the_welcome_dashboard_page->post_status = 'publish';
        $the_welcome_dashboard_page_id = wp_update_post( $the_welcome_dashboard_page );

    }
    delete_option( 'welcome_dashboard_page_id' );
    add_option( 'welcome_dashboard_page_id', $the_welcome_dashboard_page_id );

/*  E N D  */

   /* C R E A T E  Your Listings P A G E */
   // global $wpdb;

    $your_listings_title = 'Your Listings';
    $your_listings = 'your-listings';

    // the menu entry...
    delete_option("your_listings_page_title");
    add_option("your_listings_page_title", $your_listings_title, '', 'yes');
    // the slug...
    delete_option("your_listings_page_name");
    add_option("your_listings_page_name", $your_listings, '', 'yes');
    // the id...
    delete_option("your_listings_page_id");
    add_option("your_listings_page_id", '0', '', 'yes');

    $the_your_listings_page = get_page_by_title( $your_listings_title );
    if ( ! $the_your_listings_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $your_listings_title;
        $_p['post_content'] = "[wp_your_listings_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_your_listings_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_your_listings_page_id = $the_your_listings_page->ID;

        //make sure the page is not trashed...
        $the_your_listings_page->post_status = 'publish';
        $the_your_listings_page_id = wp_update_post( $the_your_listings_page );

    }
    delete_option( 'your_listings_page_id' );
    add_option( 'your_listings_page_id', $the_your_listings_page_id );

/*  E N D  */

   /* C R E A T E  Add Your Care Home P A G E */
   // global $wpdb;

    $add_your_care_home_title = 'Add Your Care Home Property';
    $add_your_care_home = 'add-your-care-home-property';

    // the menu entry...
    delete_option("add_your_care_home_page_title");
    add_option("add_your_care_home_page_title", $add_your_care_home_title, '', 'yes');
    // the slug...
    delete_option("add_your_care_home_page_name");
    add_option("add_your_care_home_page_name", $add_your_care_home, '', 'yes');
    // the id...
    delete_option("add_your_care_home_page_id");
    add_option("add_your_care_home_page_id", '0', '', 'yes');

    $the_add_your_care_home_page = get_page_by_title( $add_your_care_home_title );
    if ( ! $the_add_your_care_home_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $add_your_care_home_title;
        $_p['post_content'] = "[wp_add_your_care_home_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_add_your_care_home_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_add_your_care_home_page_id = $the_add_your_care_home_page->ID;

        //make sure the page is not trashed...
        $the_add_your_care_home_page->post_status = 'publish';
        $the_add_your_care_home_page_id = wp_update_post( $the_add_your_care_home_page );

    }
    delete_option( 'add_your_care_home_page_id' );
    add_option( 'add_your_care_home_page_id', $the_add_your_care_home_page_id );

/*  E N D  */

   /* C R E A T E  Upgrade Membership P A G E */
   // global $wpdb;

    $upgrade_membership_title = 'Upgrade Membership';
    $upgrade_membership = 'upgrade-membership';

    // the menu entry...
    delete_option("upgrade_membership_page_title");
    add_option("upgrade_membership_page_title", $upgrade_membership_title, '', 'yes');
    // the slug...
    delete_option("upgrade_membership_page_name");
    add_option("upgrade_membership_page_name", $upgrade_membership, '', 'yes');
    // the id...
    delete_option("upgrade_membership_page_id");
    add_option("upgrade_membership_page_id", '0', '', 'yes');

    $the_upgrade_membership_page = get_page_by_title( $upgrade_membership_title );
    if ( ! $the_upgrade_membership_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $upgrade_membership_title;
        $_p['post_content'] = "[wp_upgrade_membership_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_upgrade_membership_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_upgrade_membership_page_id = $the_upgrade_membership_page->ID;

        //make sure the page is not trashed...
        $the_upgrade_membership_page->post_status = 'publish';
        $the_upgrade_membership_page_id = wp_update_post( $the_upgrade_membership_page );

    }
    delete_option( 'upgrade_membership_page_id' );
    add_option( 'upgrade_membership_page_id', $the_upgrade_membership_page_id );

/*  E N D  */

   /* C R E A T E  Property Map Search P A G E */
   // global $wpdb;

    $property_map_search_title = 'Property Map Search';
    $property_map_search = 'property-map-search';

    // the menu entry...
    delete_option("property_map_search_page_title");
    add_option("property_map_search_page_title", $property_map_search_title, '', 'yes');
    // the slug...
    delete_option("property_map_search_page_name");
    add_option("property_map_search_page_name", $property_map_search, '', 'yes');
    // the id...
    delete_option("property_map_search_page_id");
    add_option("property_map_search_page_id", '0', '', 'yes');

    $the_property_map_search_page = get_page_by_title( $property_map_search_title );
    if ( ! $the_property_map_search_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $property_map_search_title;
        $_p['post_content'] = "[wp_property_map_search_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_property_map_search_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_property_map_search_page_id = $the_property_map_search_page->ID;

        //make sure the page is not trashed...
        $the_property_map_search_page->post_status = 'publish';
        $the_property_map_search_page_id = wp_update_post( $the_property_map_search_page );

    }
    delete_option( 'property_map_search_page_id' );
    add_option( 'property_map_search_page_id', $the_property_map_search_page_id );

/*  E N D  */

   /* C R E A T E  Update Property P A G E */
   // global $wpdb;

    $update_your_property_title = 'Update Property';
    $update_your_property = 'update-property';

    // the menu entry...
    delete_option("update_your_property_page_title");
    add_option("update_your_property_page_title", $update_your_property_title, '', 'yes');
    // the slug...
    delete_option("update_your_property_page_name");
    add_option("update_your_property_page_name", $update_your_property, '', 'yes');
    // the id...
    delete_option("update_your_property_page_id");
    add_option("update_your_property_page_id", '0', '', 'yes');

    $the_update_your_property_page = get_page_by_title( $update_your_property_title );
    if ( ! $the_update_your_property_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $update_your_property_title;
        $_p['post_content'] = "[wp_update_your_property_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_update_your_property_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_update_your_property_page_id = $the_update_your_property_page->ID;

        //make sure the page is not trashed...
        $the_update_your_property_page->post_status = 'publish';
        $the_update_your_property_page_id = wp_update_post( $the_update_your_property_page );

    }
    delete_option( 'update_your_property_page_id' );
    add_option( 'update_your_property_page_id', $the_update_your_property_page_id );

/*  E N D  */

   /* C R E A T E  Property Sign Up P A G E */
   // global $wpdb;

    $property_sign_up_title = 'Property Sign Up';
    $property_sign_up = 'property-sign-up';

    // the menu entry...
    delete_option("property_sign_up_page_title");
    add_option("property_sign_up_page_title", $property_sign_up_title, '', 'yes');
    // the slug...
    delete_option("property_sign_up_page_name");
    add_option("property_sign_up_page_name", $property_sign_up, '', 'yes');
    // the id...
    delete_option("property_sign_up_page_id");
    add_option("property_sign_up_page_id", '0', '', 'yes');

    $the_property_sign_up_page = get_page_by_title( $property_sign_up_title );
    if ( ! $the_property_sign_up_page ) {

        // Create post object
        $_p = array();
        $_p['post_title'] = $property_sign_up_title;
        $_p['post_content'] = "[wp_property_sign_up_shortcode]";
        $_p['post_status'] = 'publish';
        $_p['post_type'] = 'page';
        $_p['comment_status'] = 'closed';
        $_p['ping_status'] = 'closed';
        $_p['post_category'] = array(1); // the default 'Uncatrgorised'

        // Insert the post into the database
        $the_property_sign_up_page_id = wp_insert_post( $_p );

    }
    else {
        // the plugin may have been previously active and the page may just be trashed...

        $the_property_sign_up_page_id = $the_property_sign_up_page->ID;

        //make sure the page is not trashed...
        $the_property_sign_up_page->post_status = 'publish';
        $the_property_sign_up_page_id = wp_update_post( $the_property_sign_up_page );

    }
    delete_option( 'property_sign_up_page_id' );
    add_option( 'property_sign_up_page_id', $the_property_sign_up_page_id );

/*  E N D  */






  


?>