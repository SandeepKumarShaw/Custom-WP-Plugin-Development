<div class="list-actions"></div>
<div class="list-header">
  <div class="img"></div>
  <div class="username"><?php /* translators: wordpress */ _e('Username'); ?></div>
  <div class="first-name"><?php /* translators: woocommerce */ _e('First Name', 'woocommerce' ); ?></div>
  <div class="last-name"><?php /* translators: woocommerce */ _e('Last Name', 'woocommerce' ); ?></div>
  <div class="email"><?php /* translators: wordpress */ _e('Email'); ?></div>
  <div class="spent"><?php /* translators: woocommerce */ _e('Money Spent', 'woocommerce' ); ?></div>
  <div class="orders"><?php /* translators: woocommerce */ _e('Orders', 'woocommerce' ); ?></div>
  <div class="last-order"><?php /* translators: woocommerce */ _e('Last order', 'woocommerce' ); ?></div>
  <div class="actions"><?php /* translators: woocommerce */ _e('Actions', 'woocommerce'); ?></div>
</div>
<div class="panel-body list list-striped"></div>
<div class="panel-footer list-footer"></div>