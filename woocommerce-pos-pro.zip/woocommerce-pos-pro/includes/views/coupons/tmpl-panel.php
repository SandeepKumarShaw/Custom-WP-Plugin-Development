<div class="list-actions"></div>
<div class="list-header">
  <div><?php /* translators: woocommerce */ _e('Code', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Coupon type', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Coupon amount', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Description', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Products IDs', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Usage Limit', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Expiry Date', 'woocommerce'); ?></div>
</div>
<div class="panel-body list list-striped"></div>
<div class="panel-footer list-footer"></div>