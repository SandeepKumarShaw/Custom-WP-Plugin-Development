<div class="panel-header list-actions products-actions"></div>
<div class="list-header products-header">
  <div class="img"></div>
  <div class="title"><?php /* translators: woocommerce */ _e('Product', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('In stock', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Regular price', 'woocommerce'); ?></div>
  <div><?php /* translators: woocommerce */ _e('Sale price', 'woocommerce'); ?></div>
</div>
<div class="panel-body list products-list list-striped"></div>
<div class="panel-footer products-footer"></div>