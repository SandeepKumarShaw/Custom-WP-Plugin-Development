<div class="panel-header list-actions"></div>
<div class="list-header">
  <div class="status"><?php /* translators: woocommerce */ _e('Status', 'woocommerce'); ?></div>
  <div class="order"><?php /* translators: woocommerce */ _e('Order', 'woocommerce'); ?></div>
  <div class="customer"><?php /* translators: woocommerce */ _e('Customer', 'woocommerce'); ?></div>
  <div class="note"><?php /* translators: woocommerce */ _e('Note', 'woocommerce'); ?></div>
  <div class="date"><?php /* translators: woocommerce */ _e('Date', 'woocommerce' ); ?></div>
  <div class="total"><?php /* translators: woocommerce */ _e('Total', 'woocommerce' ); ?></div>
  <div class="actions"><?php /* translators: woocommerce */ _e('Actions', 'woocommerce'); ?></div>
</div>
<div class="panel-body list list-striped"></div>
<div class="panel-footer list-footer"></div>