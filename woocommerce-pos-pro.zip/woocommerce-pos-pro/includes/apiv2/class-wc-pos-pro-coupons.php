<?php

/**
 * POS Pro Coupons Class
 *
 * @class    WC_POS_Pro_API_Coupons
 * @package  WooCommerce POS Pro
 * @author   Paul Kilmurray <paul@kilbot.com.au>
 * @link     http://www.woopos.com.au
 */

class WC_POS_Pro_APIv2_Coupons extends WC_POS_API_Abstract {

  public function __construct() {

  }

}