= 0.4.13 - 2017/06/15 = 
* Fix: Customer name display on Orders page

= 0.4.11 - 2017/05/31 =
* Improve translations

= 0.4.10 - 2017/05/26 =
* Fix: Receipt date time zone
* Fix: Default pro receipt template

= 0.4.9 =
* Fix: stores admin settings

= 0.4.8 =
* Fix: create/update customer data for WC 3
* Fix: edit product name

= 0.4.7 =
* Compatibility fixes for WooCommerce 3

= 0.4.6 =
* Compatibility fix for WooCommerce 2.6

= 0.4.5 =
* New: Edit customers during checkout

= 0.4.4 =
* Fix: fatal error on Add New Store page

= 0.4.3 =
* New: setting to automatically generate customer username
* New: field to choose customer username if not automatically generated
* Fix: quick update link in WP Admin Plugins

= 0.4.2 =
* New: Sales by Store report
* New: Store by Payment Method report
* Fix: decimal quantity input on product page
* Compatibility update for WooCommerce POS 0.4.1