<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */
define('DB_NAME', 'wordpress_mary-land-farm');

/** MySQL database username */
define('DB_USER', 'wordpress');

/** MySQL database password */
define('DB_PASSWORD', 'thisiswordpress@New');

/** MySQL hostname */
define('DB_HOST', '192.168.2.20');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');


/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'L;HZZHN21G`K]7Gr^|+)m0aX]lUde0oNgq;gIu*xCet),{l]O[<htKi[jK_d=~ O');
define('SECURE_AUTH_KEY',  'vZGOzNw)L[lY6)/WIdj3lX/HtpT`];j) 2QIQ^%e%01P-*p(ro/:9i#Vc.MF&L*U');
define('LOGGED_IN_KEY',    '{YQi)5C_JprjgO4}xE@Ppq}4a5vl+LmE.WC^BpF-76x?$i4x;6KIb)/a]AVYz}dp');
define('NONCE_KEY',        'vkG?FB]*gy?ELJMkky3%wqcH(Zv}-rtjnREoL28O@VT?7;kKDX2851`:aT%e)Zu(');
define('AUTH_SALT',        'u`sGrmFNh MFOF2s&,@*JSjYcvy<u(<&5$tHRfz] LW/Zfr$8qSjyp=aSs$fV-I3');
define('SECURE_AUTH_SALT', '/.sT:4r}6.EaY1CQXBke[wn@DzIGGwn.0z{6S6[Mpl&<mdB.DK&]-_rGa0<Xk5aS');
define('LOGGED_IN_SALT',   'a4({ybo&wk[9A0Jp}bjegpA%N3cW81HH3GdYtTvdP=Q89WKwKf3CST6pl, }Mjv,');
define('NONCE_SALT',       'U;E=u{WMf$i9kPR_i3v:[Y]*;3pxO^>-kZiHeQueZ$J2yq/%fc~Xj+1r/oD`/O|!');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);
define('FS_METHOD', 'direct');
define('WPCF7_AUTOP', false );

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
