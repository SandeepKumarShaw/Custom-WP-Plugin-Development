jQuery(document).ready(function(){
  
  var addUserForm = jQuery("form[name='donationForm']");
  
  var validator = addUserForm.validate({
    
    rules: {
        first_name: {
            required: true,
            minlength: 2
        },
        last_Name: {
            required: true,
            minlength: 2
        },
        email: {
            required: true,
            email: true
        },
        zip: {
            required: true,            
            digits: true,
            maxlength:5,
            minlength: 5
        },
        phNo: {
            required: true
        },
        schoolOptName: {
            required: true
        },
         donationAmount: {
            required: true,
            number: true
        },        
         address: {
            required: true
            
        },
         country: {
            required: true
            
        },
         state: {
            required: true
        },
         city: {
            required: true
        }
    
    
    },
     messages: {        
        first_name: {
          required: "Please enter your First Name",
          minlength: "Your First Name must be at least 2 characters long"
        },
        last_Name: {
          required: "Please enter your Last Name",
          minlength: "Your Last Name must be at least 2 characters long"
        },
        email: {
          required: "Please enter your Email Address",
          email: "Please enter a valid email address"
        },
        zip: {
          required: "Please enter your Zip Code",
          digits: "Please enter only digits."
        },
        phNo: {
          required: "Please enter your Phone Number"
        },
        schoolOptName: {
          required: "Please select donation school"
        },
        donationAmount: {
          required: "Please enter Amount to Donate"
        },
        address: {
          required: "Please enter your Address"
        },
        country: {
          required: "Please enter your Country Name"
        }
        ,
        state: {
          required: "Please enter your State Name"
        }
        ,
        city: {
          required: "Please enter your City Name"
        }
    }

  });
});
