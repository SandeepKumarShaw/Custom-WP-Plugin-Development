<?php
/*
  Plugin Name: Donation List For paypal
  Plugin URI: https://www.example.com/
  Description: This plugin integrates Donation List For paypal
  Version: 1.0
  Author: WP Team
  Author URI: https://www.example.com/
*/


if (!defined('ABSPATH')){//Exit if accessed directly
    exit;
}

include_once('inc/donation_shortcode_view.php');

include_once('inc/payment-succes-page.php');

include_once('inc/payment-succes.php');

register_activation_hook(__FILE__, 'paymentsuc_install' );
register_deactivation_hook(__FILE__, 'paymentsuc_deactivation' );



function payment_success_foo() {

    return Donation_Paypal_payment_success(); 
}
add_shortcode('payment_success', 'payment_success_foo');



function dlfp_enqueue_scripts(){

    wp_enqueue_script( 'jqueryValidateJs', plugin_dir_url( __FILE__ ) . 'js/jquery.validate.js', array('jquery'),'', true );
    wp_enqueue_script( 'jquerydlfp', plugin_dir_url( __FILE__ ) . 'js/dlfp_common.js', array('jqueryValidateJs'),'', true );
    wp_enqueue_script( 'jquerymaskedinputUs', plugin_dir_url( __FILE__ ) . 'js/jquery.maskedinput.js', array('jquery'),'', true );
    wp_enqueue_script( 'jquerydlfphone', plugin_dir_url( __FILE__ ) . 'js/dlfp_usphone.js', array('jquerymaskedinputUs'),'', true );
    //wp_enqueue_script( 'jquerydlfadditionalmethods', plugin_dir_url( __FILE__ ) . 'js/additional-methods.js', array('jqueryValidateJs'),'', true );
    //wp_enqueue_script( 'jquerydlfadditionalmethods', 'https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js', array('jqueryValidateJs'),'', true );


}
add_action( 'wp_enqueue_scripts', 'dlfp_enqueue_scripts' );



global $cltd_example_db_version;
$cltd_example_db_version = '1.1'; // version changed from 1.0 to 1.1

function cltd_example_install()
{
    global $wpdb;
    global $cltd_example_db_version;

    $table_name = $wpdb->prefix . 'donner'; // do not forget about tables prefix

    
    $sql = "CREATE TABLE " . $table_name . " (
      id int(11) NOT NULL AUTO_INCREMENT,
      txn_id VARCHAR(255) NOT NULL,
      name tinytext NOT NULL,
      email VARCHAR(255) NOT NULL,
      phone VARCHAR(255) NOT NULL,
      address VARCHAR(255) NOT NULL,
      state VARCHAR(255) NOT NULL,
      city VARCHAR(255) NOT NULL,
      zip VARCHAR(255) NOT NULL,
      school_name VARCHAR(255) NOT NULL,
      donate_amount VARCHAR(255) NOT NULL,
      donation_type VARCHAR(255) NOT NULL,
      staus VARCHAR(255) NOT NULL,
      date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
      PRIMARY KEY  (id)
    );";



    // we do not execute sql directly
    // we are calling dbDelta which cant migrate database
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // save current database version for later use (on upgrade)
    add_option('cltd_example_db_version', $cltd_example_db_version);


    $installed_ver = get_option('cltd_example_db_version');
    if ($installed_ver != $cltd_example_db_version) {
        $sql = "CREATE TABLE " . $table_name . " (
         id int(11) NOT NULL AUTO_INCREMENT,
      txn_id VARCHAR(255) NOT NULL,
      name tinytext NOT NULL,
      email VARCHAR(255) NOT NULL,
      phone VARCHAR(255) NOT NULL,
      address VARCHAR(255) NOT NULL,
      state VARCHAR(255) NOT NULL,
      city VARCHAR(255) NOT NULL,
      zip VARCHAR(255) NOT NULL,
      school_name VARCHAR(255) NOT NULL,
      donate_amount VARCHAR(255) NOT NULL,
      donation_type VARCHAR(255) NOT NULL,
      staus VARCHAR(255) NOT NULL,
      date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
      PRIMARY KEY  (id)
        );";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // notice that we are updating option, rather than adding it
        update_option('cltd_example_db_version', $cltd_example_db_version);
    }
}

register_activation_hook(__FILE__, 'cltd_example_install');

/**
 * Trick to update plugin database, see docs
 */
function cltd_example_update_db_check()
{
    global $cltd_example_db_version;
    if (get_site_option('cltd_example_db_version') != $cltd_example_db_version) {
        cltd_example_install();
    }
}

add_action('plugins_loaded', 'cltd_example_update_db_check');

/**
 * PART 2. Defining Custom Table List
 * ============================================================================
 */

if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}


class Custom_Table_Example_List_Table extends WP_List_Table
{
   
    function __construct()
    {
        global $status, $page;

        parent::__construct(array(
            'singular' => 'donor',
            'plural' => 'donors',
        ));
    }


    function column_default($item, $column_name)
    {
        return $item[$column_name];
    }

    function column_age($item)
    {
        return '<em>' . $item['address'] . '</em>';
    }


    function column_name($item)
    {
    
        $actions = array(
            'edit' => sprintf('<a href="?page=Donners_form&id=%s">%s</a>', $item['id'], __('View', 'ff')),
            'delete' => sprintf('<a href="?page=%s&action=delete&id=%s">%s</a>', $_REQUEST['page'], $item['id'], __('Delete', 'ff')),
        );

        return sprintf('%s %s',
            $item['name'],
            $this->row_actions($actions)
        );
    }

 
    function column_cb($item)
    {
        return sprintf(
            '<input type="checkbox" name="id[]" value="%s" />',
            $item['id']
        );
    }

  
    function get_columns()
    {
        $columns = array(
            'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
            'name' => __('Name', 'cltd_example'),
            'email' => __('E-Mail', 'cltd_example'),
            'phone' =>__('Phone Number', 'cltd_example'),
            'address' => __('Address', 'cltd_example'),
             'donate_amount' => __('Donation Amount ($)', 'cltd_example'),
        'date' =>__('Donation Date', 'cltd_example'),
        );
        return $columns;
    }
    function get_sortable_columns()
    {
        $sortable_columns = array(
            'name' => array('name', true),
            'email' => array('email', false),
            'phone' => array('phone', false),
            'address' => array('address', false),
             'donate_amount' => array('donate_amount', false),
        'date' =>array('date', false),
        );
        return $sortable_columns;
    }
 function get_bulk_actions()
    {
        $actions = array(
            'delete' => 'Delete'
        );
        return $actions;
    }

    /**
     * This method processes bulk actions
     */
    function process_bulk_action()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'donner'; // do not forget about tables prefix

        if ('delete' === $this->current_action()) {
            $ids = isset($_REQUEST['id']) ? $_REQUEST['id'] : array();
            if (is_array($ids)) $ids = implode(',', $ids);

            if (!empty($ids)) {
                $wpdb->query("DELETE FROM $table_name WHERE id IN($ids)");
            }
        }
    }

    /**
     * [REQUIRED] This is the most important method
     *
     * It will get rows from database and prepare them to be showed in table
     */
    function prepare_items()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'donner'; // do not forget about tables prefix

        $per_page = 5; // constant, how much records will be shown per page

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();

        // here we configure table headers, defined in our methods
        $this->_column_headers = array($columns, $hidden, $sortable);

        // [OPTIONAL] process bulk action if any
        $this->process_bulk_action();

        // will be used in pagination settings
        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
        $this->items = $wpdb->get_results("SELECT * FROM $table_name ", ARRAY_A);
 $search = ( isset( $_REQUEST['s'] ) ) ? $_REQUEST['s'] : false;
/* If the value is not NULL, do a search for it. */
if( $search != NULL ){
       
        // Trim Search Term
        $search = trim($search);
       
        /* Notice how you can search multiple columns for your search term easily, and return one data set */
        $this->items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE `name` LIKE '%%%s%%' OR `email` LIKE '%%%s%%'", $search, $search), ARRAY_A);
 //print_r($wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE `name` LIKE '%%%s%%' OR `email` LIKE '%%%s%%'", $search, $search), ARRAY_A));
}

        // prepare query params, as usual current page, order by and order direction
        $paged = isset($_REQUEST['paged']) ? max(0, intval($_REQUEST['paged']) - 1) : 0;
        $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'name';
        $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'asc';

        // [REQUIRED] define $items array
        // notice that last argument is ARRAY_A, so we will retrieve array
       // $this->items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY $orderby $order LIMIT %d OFFSET %d", $per_page, $paged), ARRAY_A);

        // [REQUIRED] configure pagination
        $this->set_pagination_args(array(
            'total_items' => $total_items, // total items defined above
            'per_page' => $per_page, // per page constant defined at top of method
            'total_pages' => ceil($total_items / $per_page) // calculate pages count
        ));
    }
}

/**
 * PART 3. Admin page
 * ============================================================================
 */
function cltd_example_admin_menu()
{
    add_menu_page(__('Donors', 'cltd_example'), __('Donors', 'cltd_example'), 'activate_plugins', 'Donors', 'cltd_example_Donners_page_handler');
    add_submenu_page('Donors', __('Donors', 'cltd_example'), __('Donors', 'cltd_example'), 'activate_plugins', 'Donors', 'cltd_example_Donners_page_handler');
    // add new will be described in next part
    add_submenu_page( null, __('Add new', 'cltd_example'), __('Add new', 'cltd_example'), 'activate_plugins', 'Donners_form', 'cltd_example_Donners_form_page_handler');
}

add_action('admin_menu', 'cltd_example_admin_menu');

/**
 * List page handler
 */
function cltd_example_Donners_page_handler()
{
    global $wpdb;

    $table = new Custom_Table_Example_List_Table();
    $table->prepare_items();
    
  //  $table->search_box('search', 'search_id');
    $message = '';
    if ('delete' === $table->current_action()) {
        $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted: %d', 'cltd_example'), count($_REQUEST['id'])) . '</p></div>';
    }
    ?>
<div class="wrap">

    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    <h2><?php _e('Donors', 'cltd_example')?>
    </h2>
    <?php echo $message; ?>

    <form id="Donners-table" method="GET">
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>"/>
         
        <?php
        $table->search_box('search', 'search_id');
        $table->display() ?>
    </form>
<?php if( isset($_POST['s']) ){
                $table->prepare_items($_POST['s']);
        } else {
                $table->prepare_items();
        }?>
</div>
<?php
}

/**
 * PART 4. Form for adding andor editing row
 * ============================================================================
 *
 * In this part you are going to add admin page for adding andor editing items
 * You cant put all form into this function, but in this example form will
 * be placed into meta box, and if you want you can split your form into
 * as many meta boxes as you want
 *
 * http://codex.wordpress.org/Data_Validation
 * http://codex.wordpress.org/Function_Reference/selected
 */

/**
 * Form page handler checks is there some data posted and tries to save it
 * Also it renders basic wrapper in which we are callin meta box render
 */
function cltd_example_Donners_form_page_handler()
{
    ob_start();
    global $wpdb;
    $table_name = $wpdb->prefix . 'donner'; // do not forget about tables prefix

    $message = '';
    $notice = '';

    // this is default $item which will be used for new records
    $default = array(
        'id' => 0,
        'name' => '',
        'email' => '',
         'phone' => '',
        'address' => '',
        'donate_amount' => '',
        'date' =>'',
    );

    // here we are verifying does this request is post back and have correct nonce
    if ( isset($_REQUEST['nonce']) && wp_verify_nonce($_REQUEST['nonce'], basename(__FILE__))) {
        // combine our default item with request params
        $item = shortcode_atts($default, $_REQUEST);
        // validate data, and if all ok save item to database
        // if id is zero insert otherwise update
        $item_valid = cltd_example_validate_organization($item);
        if ($item_valid === true) {
            if ($item['id'] == 0) {
                $result = $wpdb->insert($table_name, $item);
                $item['id'] = $wpdb->insert_id;
                if ($result) {
                    $message = __('Item was successfully saved', 'cltd_example');
                } else {
                    $notice = __('There was an error while saving item', 'cltd_example');
                }
            } else {
                $result = $wpdb->update($table_name, $item, array('id' => $item['id']));
                if ($result) {
                    $message = __('Item was successfully updated', 'cltd_example');
                } else {
                    $notice = __('There was an error while updating item', 'cltd_example');
                }
            }
        } else {
            // if $item_valid not true it contains error message(s)
            $notice = $item_valid;
        }
    }
    else {
        // if this is not post back we load item to edit or give new one to create
        $item = $default;
        if (isset($_REQUEST['id'])) {
            $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $_REQUEST['id']), ARRAY_A);
            if (!$item) {
                $item = $default;
                $notice = __('Item not found', 'cltd_example');
            }
        }
    }

 
    ?>
<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    <h2><?php _e('Doner', 'cltd_example')?> 
        <?php 
        $path = 'admin.php?page=Donors';
        $url = admin_url($path);
         ?>
        <a class="add-new-h2" href="<?php echo $url;?>"><?php _e('back to list', 'cltd_example')?></a>
    </h2>
    <div id="col-container">
        <div id="col-right">
            <div class="col-wrap">
            <h3>Donation Details</h3>
            <table class="widefat">
                <tbody>
                    <tr><th>Date</th><td><?php echo $item['date'];?></td></tr>
                    <tr><th>Amount</th><td>$<?php echo $item['donate_amount'];?></td></tr>
                    <tr><th>Payment Method</th><td>PayPal</td></tr>
                    <tr><th>Transaction ID</th><td><?php echo $item['txn_id'];?></td></tr>
                    <tr><th>Payment Status</th><td><?php echo $item['staus'];?></td></tr>
                    <tr><th>Arizona Tax Deductible Donation</th><td><?php echo $item['donation_type'];?></td></tr>
                    <tr><th>Donation school</th><td><?php echo $item['school_name'];?></td></tr>
                </tbody>
            </table>
            </div> 
        </div> <!-- col-right -->

         <div id="col-left">
            <div class="col-wrap">
            <h3>Donor Information</h3>
            <table class="widefat">
                <tbody>
                    <tr><th>Name</th><td><?php echo $item['name'];?></td></tr>
                    <tr><th>Address</th><td><?php echo $item['address'];?></td></tr>
                    <tr><th>State</th><td><?php echo $item['state'];?></td></tr>
                    <tr><th>City</th><td><?php echo $item['city'];?></td></tr>
                    <tr><th>Zip</th><td><?php echo $item['zip'];?></td></tr>
                    <tr><th>Phone</th><td><?php echo $item['phone'];?></td></tr>
                    <tr><th>Email</th><td><?php echo $item['email'];?></td></tr>
                </tbody>
            </table>
            </div> 
        </div> <!-- col-left -->

    </div>    
</div>    
<?php
}
return ob_get_clean();



function cltd_example_languages()
{
    load_plugin_textdomain('cltd_example', false, dirname(plugin_basename(__FILE__)));
}

add_action('init', 'cltd_example_languages');



