<?php 
ob_start();

function Donation_Paypal_payment_success(){

$paypalURL = 'https://www.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
$paypalID = 'anthonydocameen@gmail.com'; //Business Email
global $wpdb;

$item_number = $_GET['item_name']; 
$txn_id = $_GET['tx'];
$payment_gross = $_GET['amt'];
$currency_code = $_GET['cc'];
$payment_status = $_GET['st'];
$faname = $_GET['faname']; 
$lname = $_GET['lname'];
$name=$faname.' '.$lname;
$email = $_GET['email'];
$phNo = $_GET['phNo'];
$city = $_GET['city'];
$state = $_GET['state'];
$country = $_GET['country'];
$zip = $_GET['zip'];
$address = $_GET['address'];

if(!empty($_GET['schoolOptName'])){
     $schoolOptName = $_GET['schoolOptName'];
}

if(!empty($_GET['donationType'])){
    $donationType = $_GET['donationType'];
}

if($_GET['donationAmount']==''){
	$donationAmount='Undesignated';
}
else{
	$donationAmount = $_GET['donationAmount'];
}

$admin_email = get_option( 'admin_email' );

if(!empty($txn_id)){

$timestamp = $_GET['dat'];
$dat = date("Y-m-d H:i:s", $timestamp);
	global $wpdb;
	$table_name = $wpdb->prefix."donner";
	//$wpdb->show_errors(); 
	//echo $table_name;    
    $insert_query = "INSERT INTO ".$table_name."(txn_id,name,email,phone,address,state,city,zip,school_name,donate_amount,donation_type,staus,date) values ('".$_GET['tx']."','".$name."','".$_GET['email']."','".$_GET['phNo']."', '".$_GET['address']."', '".$_GET['state']."','".$_GET['city']."','".$_GET['zip']."','".$_GET['schoolOptName']."','".$donationAmount."','".$_GET['donationType']."','".$_GET['st']."','".$dat."')"; 
	$insertResult=$wpdb->query($insert_query);
	if ($insertResult) {
		$to = $admin_email;
        $subject = "Skyline Education Donation";

       include_once('payment-succes-email.php');


		//Always set content-type when sending HTML email
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

		//More headers
		$headers .= "From: " . $name . '<' . $email .'>' . "\r\n";
        $donation_mail_admin = mail($to, $subject, $AdminMessage, $headers);
        if ($donation_mail_admin) {

        	//Always set content-type when sending HTML email
		    $headers1 = "MIME-Version: 1.0" . "\r\n";
		    $headers1 .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        	//More headers
        	$headers1 .= "From: " . get_bloginfo( 'name' ) . '<' . $to .'>' . "\r\n";
	        $donation_mail_user = mail($email, $subject, $UserMessage, $headers1);
	        if ($donation_mail_user) {
	        	$htm = '<div class="row">	
	                    <div class="col-md-8 col-sm-8 payment-success-donate">
		                <div class="payment-success">
			            <h4 class="success-message"><p>Your payment has been successful.</p></h4>
		                <strong class="payment-id">Your Payment ID - '.$txn_id.'.</strong>
		                <a href="'.site_url().'" class="red-btn small-btn small-btn-back donationSubmit">BACK TO HOME</a>
		                </div>
                        </div>
                        </div>';
                echo $htm;        
	        }else{
	        	$htm = '<div class="row">	
	                    <div class="col-md-8 col-sm-8 payment-success-donate">
		                <div class="payment-success">
			            <h4 class="success-message"><p>Your payment has been failed.</p></h4>
		                </div>
                        </div>
                        </div>';
                echo $htm;      

	        }
        }
	}
 } 
	
}

