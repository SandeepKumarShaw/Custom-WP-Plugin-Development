<?php

function paymentsuc_install()
{
/*C R E A T E     A   P A Y M E N T  S U C C E S    B A C K E N D    P A G E*/
                global $wpdb;
            
                $payment_page_title = 'Payment Success';
                $payment_page_name = 'payment-success';
            
                // the menu entry...
                delete_option("my_payment_page_title");
                add_option("my_payment_page_title", $payment_page_title, '', 'yes');
                // the slug...
                delete_option("my_payment_page_name");
                add_option("my_payment_page_name", $payment_page_name, '', 'yes');
                // the id...
                delete_option("my_payment_page_id");
                add_option("my_payment_page_id", '0', '', 'yes');
            
                $payment_page = get_page_by_title( $payment_page_title );
            
                if ( ! $payment_page ) {
            
                    // Create post object
                    $_p = array();
                    $_p['post_title'] = $payment_page_title;
                    $_p['post_content'] = "[payment_success]";
                    $_p['post_status'] = 'publish';
                    $_p['post_type'] = 'page';
                    $_p['comment_status'] = 'closed';
                    $_p['ping_status'] = 'closed';
                    $_p['post_category'] = array(1); // the default 'Uncatrgorised'
            
                    // Insert the post into the database
                    $the_page_id = wp_insert_post( $_p );
            
                }
                else {
                    // the plugin may have been previously active and the page may just be trashed...
            
                    $the_page_id = $payment_page->ID;
            
                    //make sure the page is not trashed...
                    $payment_page->post_status = 'publish';
                    $the_page_id = wp_update_post( $payment_page );
            
                }
  
}
function paymentsuc_deactivation()
{
global $wpdb;
    /*************FOR payment success PAGE START***********/
    $the_page_title = get_option( "my_payment_page_title" );
    $my_payment_page_name = get_option( "my_payment_page_name" );
    $paymentpage = get_page_by_path($my_payment_page_name);
    
    
    //  the id of our page...
    $payment_page_id = $paymentpage->ID;
   // $payment_page_id = get_option( 'my_payment_page_id' );
    if( $payment_page_id ) {

        wp_delete_post( $payment_page_id ); // this will trash, not delete

    }

    delete_option("my_payment_page_title");
    delete_option("my_payment_page_name");
    delete_option("my_payment_page_id");
    /*************FOR payment success PAGE END***********/
}