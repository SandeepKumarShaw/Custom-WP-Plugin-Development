<?php

ob_start();

function Donation_Paypal_payment_accept(){


?>

        <p>A donation is a personal investment in the lives of children in your community and in the success of future generations of young Americans. Making a donation today will impact thousands of students lives in the Arizona Valley. If you would like to make a donation to any one of our schools you may claim these under federal tax law as a contribution to a non-profit 501 (c) 3 organization. See your tax adviser on how to claim these deductions. Visit the IRS page for more information: <a href="#" class="taxAnchor">Charitable Contribution Deductions</a></p>
        <div class="donation-form-sec">
            <form id="donation_form" class="donation-form" name="donationForm" action="" method="post">
                <div class="row">
                    <div class="col-md-4">
                        <label for="first_name">First Name*</label>
                        <div class="form-group">
                           <input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name*">
                        </div>
                    </div>   
                    <div class="col-md-4">
                        <label for="last_Name">Last Name*</label>
                        <div class="form-group">
                           <input type="text" class="form-control" id="last_Name" name="last_Name" placeholder="Last Name*">
                        </div>
                    </div>   
                    <div class="col-md-4">
                        <label for="phNo">Phone Number*</label>
                       <div class="form-group">
                          <input type="text" class="form-control" id="phNo" name="phNo" placeholder="Phone Number">
                       </div>
                    </div>                     
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label for="email">Email Address*</label>
                       <div class="form-group">
                          <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                       </div>
                    </div>
                    <div class="col-md-6">
                      <label for="address">Address</label>
                       <div class="form-group">
                          <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                       </div>
                    </div>
                    <!-- <div class="col-md-4">
                        <label for="country">Country</label>
                       <div class="form-group">
                          <input type="text" class="form-control" id="country" name="country" placeholder="Country">
                       </div> 
                    </div>  -->
                </div>
                <div class="row"> 
                     <div class="col-md-4">
                        <label for="state">State</label>
                       <div class="form-group">
                          <input type="text" class="form-control" id="state" name="state" placeholder="State">
                       </div> 
                    </div>      
                    <div class="col-md-4">
                       <label for="city">City</label>
                       <div class="form-group">
                          <input type="text" class="form-control" id="city" name="city" placeholder="City">
                       </div>
                    </div>                 
                    
                    <div class="col-md-4">
                        <label for="country">Zip*</label>
                       <div class="form-group">
                          <input type="text" class="form-control" id="zip" name="zip" placeholder="Zip*">
                       </div> 
                    </div>
                </div>
                <div class="row">
                     <input type="hidden" name="currency_code" value="USD">
                    <input type="hidden" name="quantity" value="1">
                                
                    <div class="col-md-6">
                        <div class="form-group"> 
                            <label for="schoolOptName">Select the school to which you'd like to donate:*</label>
                             
                            <select class="form-control form-control-lg aftertext schoolOpt" name="schoolOptName">
                                <option value="" selected="selected">Select a school</option>
                                <option value="South Phoenix Prep & Arts Academy">South Phoenix Prep & Arts Academy</option>
                                <option value="South Valley Prep & Arts School">South Valley Prep & Arts School</option>
                                <option value="Skyline Prep High School">Skyline Prep High School</option>
                                <option value="South Phoenix Campus Preschool">South Phoenix Campus Preschool</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                         <div class="col-md-12">
                        <label for="donationType">Is this an Arizona Tax Deductible Donation?  <a class="various" href="#whatIsThis">What is this?</a></label>
                        <div id="whatIsThis" style="display: none;">
                            <p>The State of Arizona continues to offer the School Tax Credit that can pass up to $400 (for married persons filing jointly) from your State tax bill to a public/charter school of your choice, without costing you anything! (Single and head of household filers may contribute up to $200).
        
        The taxpayer does not have to have a student enrolled in an Arizona school. This donation of up to $400/$200 is really an advanced payment on your Arizona taxes, just as if you had it taken out of your paycheck.
        
        This opportunity provides our School with much needed funds to support important extra-curricular activities. Our mission is to build strong, positive character traits and develop the creative skills of our students.
        
        Help us build character and creativity and we'll help you reduce your taxes! For more information visit: <a href="#" class="taxAnchor">State of Arizona Department of Revenue: School Tax Credits</a></p>
                        </div>
                       <div class="col-md-3">
                         <div class="form-check form-check-inline">
                          <label class="form-check-label">
                            <input id="1" class="sk-radio" type="radio" name="donationType" value="yes" checked>YES
                          </label>
                        </div>

                       </div>
                        <div class="col-md-3">
                        <div class="form-check form-check-inline">
                          <label class="form-check-label">
                            <input id="2" class="sk-radio" type="radio" name="donationType" value="no">NO
                          </label>
                        </div>
                        </div>               

                        <div class="col-md-3"></div>
                        <div class="col-md-3"></div>
                       
                        </div>

                    </div>
                </div> 
                <div class="row">
                    <div class="col-md-4">
                        <label for="donationAmount">Amount to Donate($):*</label>
                        <div class="form-group">
                            <input type="text" name="donationAmount" class="form-control donationAmount">
                        </div>
                    </div>                  
                </div>
                <div class="row">
                                         <div class="col-md-12">
                        <span class="donationNote">Pressing DONATE will take you to Paypal where you can enter your payment information and complete your transaction. Thank you for your donation! </span>

                     </div>
                       <div class="form-group"> 
                        <div class="col-md-12">
                          <input class="red-btn donationSubmit" name="donationSubmit" type="submit" value="DONATE">
                        </div>
                      </div>

                </div>    
        </div>
                
            </form>
        </div>
   

<?php
//Paypal Redirection form with hidden value
if (isset($_POST['donationSubmit'])) {

  $timestamp = time();
//$dat = date("F d, Y h:i:s", $timestamp);

  var_dump($_POST);
    if(!empty($_POST['schoolOptName'])){
        $schoolOptName = $_POST['schoolOptName'];
    }
    if(!empty($_POST['donationAmount'])){
        $donationAmount = $_POST['donationAmount'];
    }
    
//Set useful variables for paypal form
//$paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
//$paypalID = 'bucnorsteve-facilitator@gmail.com'; //Business Email

if($schoolOptName == "South Phoenix Prep & Arts Academy"){
    $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
    $paypalID = 'bucnorsteve-facilitator@gmail.com'; //Business Email
}elseif($schoolOptName == "South Valley Prep & Arts School"){
    $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
    $paypalID = 'bucnorsteve-facilitator@gmail.com'; //Business Email
}elseif($schoolOptName == "Skyline Prep High School"){
    $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
    $paypalID = 'bucnorsteve-facilitator@gmail.com'; //Business Email
}elseif($schoolOptName == "South Phoenix Campus Preschool"){
    $paypalURL = 'https://www.sandbox.paypal.com/cgi-bin/webscr'; //Test PayPal API URL
    $paypalID = 'bucnorsteve-facilitator@gmail.com'; //Business Email
}
?>
    <form name="paypalform" action="<?php echo $paypalURL; ?>" method="post">
                      
            <!-- Identify your business so that you can collect the payments. -->
            <input type="hidden" name="business" value="<?php echo $paypalID; ?>">
            
            <!-- Specify a Buy Now button. -->
            <input type="hidden" name="cmd" value="_xclick">
            
            <!-- Specify details about the item that buyers will purchase. -->
            <input type="hidden" name="item_name" value="Donation">
            <!-- Specify URLs -->
            
            <input type="hidden" name="amount" value="<?php echo $donationAmount;?>" />
                        
            <input type="hidden" name="currency_code" value="USD">
            <input type="hidden" name="quantity" value="1">
                         
            <input type='hidden' name='cancel_return' value='http://ironspringsdev.com/skyline-education/donate-test/'>
            <input type='hidden' name='return' value="<?php echo site_url(); ?>/payment-success/?faname=<?php echo $_POST['first_name'];?>&lname=<?php echo $_POST['last_Name'];?>&email=<?php echo $_POST['email'];?>&address=<?php echo $_POST['address'];?>&phNo=<?php echo $_POST['phNo'];?>&city=<?php echo $_POST['city'];?>&state=<?php echo $_POST['state'];?>&zip=<?php echo $_POST['zip'];?>&schoolOptName=<?php echo $schoolOptName; ?>&donationType=<?php echo $_POST['donationType'];?>&donationAmount=<?php echo $donationAmount;?>&dat=<?php echo $timestamp;?>">
    </form>
               
<script type="text/javascript">
document.paypalform.submit();
</script>
<?php }
}
add_shortcode('wp_paypal_payment', 'Donation_Paypal_payment_accept');
return ob_get_clean();
